package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewAnimator;
import android.widget.ViewFlipper;
import android.widget.ViewSwitcher;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.databinding.ActivityAboutusBinding;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class AboutUsActivity extends AppCompatActivity {
    ActivityAboutusBinding binding;

    private static final long FLIP_INTERVAL = 2000; // Adjust the interval as needed (in milliseconds)
    private Handler handler;
    private ViewFlipper viewFlipper;
    private  MeowBottomNavigation ABottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        binding = ActivityAboutusBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//        setContentView(R.layout.activity_payment);



        try{



            binding.ABottomNavigation.add(new MeowBottomNavigation.Model(1, R.drawable.ic_home));
            binding.ABottomNavigation.add(new MeowBottomNavigation.Model(2, R.drawable.ic_category));
            binding.ABottomNavigation.add(new MeowBottomNavigation.Model(3, R.drawable.ic_cart_white));
            binding.ABottomNavigation.add(new MeowBottomNavigation.Model(4, R.drawable.ic_profile));

            binding.ABottomNavigation.show(4, true);

            binding.ABottomNavigation.setOnClickMenuListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {

                        case 1:

                            Intent homeintent= new Intent(AboutUsActivity.this, DashBoard.class);
                            startActivity(homeintent);
                            break;
                        case 2:
                            Intent catintent = new Intent(AboutUsActivity.this,CategoryActivity.class);
                            startActivity(catintent);
                            break;
                        case 3:
                            Intent cartintent= new Intent(AboutUsActivity.this, CartActivity.class);
                            startActivity(cartintent);
                            break;
                        case 4:
                            Intent profileintent= new Intent(AboutUsActivity.this, UerProfileActivity.class);
                            startActivity(profileintent);
                            break;

                    }
                    return null;
                }
            });

            binding.ABottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 1:
                            Intent homeintent= new Intent(AboutUsActivity.this, DashBoard.class);
                            startActivity(homeintent);
                            break;
                    }
                    return null;
                }
            });

            binding.ABottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 2:
                            Intent catintent = new Intent(AboutUsActivity.this,CategoryActivity.class);
                            startActivity(catintent);
                            break;
                    }
                    return null;
                }
            });
            binding.ABottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 3:
                            Intent cartintent= new Intent(AboutUsActivity.this, CartActivity.class);
                            startActivity(cartintent);
                            break;
                    }
                    return null;
                }
            });
            binding.ABottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 4:
                            Intent profileintent= new Intent(AboutUsActivity.this, UerProfileActivity.class);
                            startActivity(profileintent);
                            break;
                    }
                    return null;
                }
            });


        }catch(Exception e){
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }


        try {

            viewFlipper = binding.viewFlipper;
            viewFlipper.setInAnimation(this, android.R.anim.slide_in_left);
            viewFlipper.setOutAnimation(this, android.R.anim.slide_out_right);
            viewFlipper.setAutoStart(true);

            handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    switchText();
                    handler.postDelayed(this, FLIP_INTERVAL);
                }
            }, FLIP_INTERVAL);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    private void switchText() {
        viewFlipper.showNext();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}