package com.zohausman.mycandycotton.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.hishd.tinycart.model.Cart;
import com.hishd.tinycart.model.Item;
import com.hishd.tinycart.util.TinyCartHelper;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.adapter.CartAdapter;
import com.zohausman.mycandycotton.databinding.ActivityCartBinding;
import com.zohausman.mycandycotton.model.Product;
import com.zohausman.mycandycotton.model.productDispData;

import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class CartActivity extends AppCompatActivity {
    ActivityCartBinding binding;
    CartAdapter adapter;
    ArrayList<productDispData> products;
    private MeowBottomNavigation cartBottomNav;


    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityCartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//        setContentView(R.layout.activity_cart);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);



        try{

            binding.cartBottomNavigation.add(new MeowBottomNavigation.Model(1, R.drawable.ic_home));
            binding.cartBottomNavigation.add(new MeowBottomNavigation.Model(2, R.drawable.ic_category));
            binding.cartBottomNavigation.add(new MeowBottomNavigation.Model(3, R.drawable.ic_cart_white));
            binding.cartBottomNavigation.add(new MeowBottomNavigation.Model(4, R.drawable.ic_profile));

            binding.cartBottomNavigation.show(3, true);

            binding.cartBottomNavigation.setOnClickMenuListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {

                        case 1:

                            Intent homeintent= new Intent(CartActivity.this, DashBoard.class);
                            startActivity(homeintent);
                            break;
                        case 2:
                            Intent catintent = new Intent(CartActivity.this,CategoryActivity.class);
                            startActivity(catintent);
                            break;
//                        case 3:
//                            Intent cartintent= new Intent(CartActivity.this, CartActivity.class);
//                            startActivity(cartintent);
//                            break;
                        case 4:
                            Intent profileintent= new Intent(CartActivity.this, AboutUsActivity.class);
                            startActivity(profileintent);
                            break;

                    }
                    return null;
                }
            });

            binding.cartBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 1:
                            Intent homeintent= new Intent(CartActivity.this, DashBoard.class);
                            startActivity(homeintent);
                            break;
                    }
                    return null;
                }
            });

            binding.cartBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 2:
                            Intent catintent = new Intent(CartActivity.this,CategoryActivity.class);
                            startActivity(catintent);
                            break;
                    }
                    return null;
                }
            });
//            binding.cartBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
//                @Override
//                public Unit invoke(MeowBottomNavigation.Model model) {
//                    // YOUR CODES
//                    switch (model.getId()) {
//                        case 3:
//                            Intent cartintent= new Intent(CartActivity.this, CartActivity.class);
//                            startActivity(cartintent);
//                            break;
//                    }
//                    return null;
//                }
//            });
            binding.cartBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 4:
                            Intent profileintent= new Intent(CartActivity.this, UerProfileActivity.class);
                            startActivity(profileintent);
                            break;
                    }
                    return null;
                }
            });


        }catch(Exception e){
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        products = new ArrayList<>();
        Cart cart = TinyCartHelper.getCart();

        for(Map.Entry<Item,Integer> item: cart.getAllItemsWithQty().entrySet()){
            productDispData product = (productDispData) item.getKey();
            int quantity = item.getValue();
            product.setQuantity(String.valueOf(quantity));
            products.add(product);

        };



        adapter = new CartAdapter(this, products, new CartAdapter.CartListener() {
            @Override
            public void onQuantityChanged() {
                binding.subtotal.setText(String.format("PKR %.2f", cart.getTotalPrice()));

            }
        });
        binding.sharecartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder shareText = new StringBuilder();
                for (productDispData product : products) {

                    shareText.append("Product Name: ").append(product.getPname()).append("\n");
                    shareText.append("Price: ").append(product.getPrice()).append("\n");
                    shareText.append("Quantity: ").append(product.getQuantity()).append("\n");
                    shareText.append("Available Stock:").append(product.getStock()).append("\n");
                    shareText.append("Size: ").append(product.getSize()).append("\n");
                    shareText.append("\n");

                }

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareText.toString());
                startActivity(Intent.createChooser(shareIntent, "Share via"));
            }

                });



     LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        DividerItemDecoration itemDecoration= new DividerItemDecoration(this, layoutManager.getOrientation());
        binding.cartList.setLayoutManager(layoutManager);
//        binding.cartList.addItemDecoration(itemDecoration);
        binding.cartList.setAdapter(adapter);

        binding.subtotal.setText(String.format("PKR %.2f", cart.getTotalPrice()));

         binding.continueBtn.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {

                 // Start MainActivity
                 Intent intent = new Intent(CartActivity.this, MainActivity.class);
                 startActivity(intent);

             }
         });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                // Show the confirmation dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(CartActivity.this);
                builder.setMessage("Are you sure you want to delete this product?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // User confirmed deletion, remove the item
                                adapter.removeItem(position);
                                Toast.makeText(CartActivity.this, "Deleted Successfully", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // User canceled deletion, notify the adapter to restore the item
                                adapter.notifyItemChanged(position);
                            }
                        })
                        .setCancelable(false)
                        .show();


            }

        };
        // Create an instance of ItemTouchHelper
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(itemTouchHelperCallback);

// Attach ItemTouchHelper to the RecyclerView
        itemTouchHelper.attachToRecyclerView(binding.cartList);


    }
    //onCreated ended


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}