package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.adapter.ProductAdapter;
import com.zohausman.mycandycotton.apicontroller;
import com.zohausman.mycandycotton.databinding.ActivityCategoryBinding;
import com.zohausman.mycandycotton.model.Product;
import com.zohausman.mycandycotton.model.Showall;
import com.zohausman.mycandycotton.model.productDispData;

import java.util.ArrayList;
import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CategoryActivity extends AppCompatActivity {
    ActivityCategoryBinding binding;
    ProductAdapter productAdapter;
    productDispData currentProduct;
    private ArrayList<productDispData> products;
    private Object limit;

    private MeowBottomNavigation catBottomNav;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCategoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        try{

            binding.catBottomNavigation.add(new MeowBottomNavigation.Model(1, R.drawable.ic_home));
            binding.catBottomNavigation.add(new MeowBottomNavigation.Model(2, R.drawable.ic_category));
            binding.catBottomNavigation.add(new MeowBottomNavigation.Model(3, R.drawable.ic_cart_white));
            binding.catBottomNavigation.add(new MeowBottomNavigation.Model(4, R.drawable.ic_profile));

            binding.catBottomNavigation.show(2, true);

            binding.catBottomNavigation.setOnClickMenuListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {

                    switch (model.getId()) {

                        case 1:

                            Intent homeintent= new Intent(CategoryActivity.this, DashBoard.class);
                            startActivity(homeintent);
                            break;
//                        case 2:
//                            Intent catintent = new Intent(CategoryActivity.this,CategoryActivity.class);
//                            startActivity(catintent);
//                            break;
                        case 3:
                            Intent cartintent= new Intent(CategoryActivity.this, CartActivity.class);
                            startActivity(cartintent);
                            break;
                        case 4:
                            Intent profileintent= new Intent(CategoryActivity.this, UerProfileActivity.class);
                            startActivity(profileintent);
                            break;

                    }
                    return null;
                }
            });

            binding.catBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {

                    switch (model.getId()) {
                        case 1:
                            Intent homeintent= new Intent(CategoryActivity.this, DashBoard.class);
                            startActivity(homeintent);
                            break;
                    }
                    return null;
                }
            });
//
//            binding.catBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
//                @Override
//                public Unit invoke(MeowBottomNavigation.Model model) {
//
//                    switch (model.getId()) {
//                        case 2:
//                            Intent catintent = new Intent(CategoryActivity.this,CategoryActivity.class);
//                            startActivity(catintent);
//                            break;
//                    }
//                    return null;
//                }
//            });
            binding.catBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    switch (model.getId()) {
                        case 3:
                            Intent cartintent= new Intent(CategoryActivity.this, CartActivity.class);
                            startActivity(cartintent);
                            break;
                    }
                    return null;
                }
            });
            binding.catBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {

                    switch (model.getId()) {
                        case 4:
                            Intent profileintent= new Intent(CategoryActivity.this, UerProfileActivity.class);
                            startActivity(profileintent);
                            break;
                    }
                    return null;
                }
            });


        }catch(Exception e){
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        products = new ArrayList<>();
        productAdapter = new ProductAdapter(this, products);


//        int catId = getIntent().getIntExtra("catId", 0);
        String categoryName = getIntent().getStringExtra("categoryName");


        getSupportActionBar().setTitle(categoryName);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getProducts(categoryName);

        getNewAProduct(categoryName, limit);


        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        binding.productList.setLayoutManager(layoutManager);
        binding.productList.setAdapter(productAdapter);
    }

    private void getNewAProduct(String categoryName, Object limit) {
        Call<Showall> call = apicontroller.getInstance().getapiSet().getNewArrivalProducts(categoryName, 10);
        call.enqueue(new Callback<Showall>() {
            @Override
            public void onResponse(Call<Showall> call, Response<Showall> response) {
                if (response.isSuccessful()) {
                    Showall showall = response.body();
                    if (showall != null && showall.getData() != null) {
                        List<productDispData> productList = showall.getData();
                        products.addAll(productList);
                        productAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(CategoryActivity.this, "No products found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(CategoryActivity.this, "Failed to fetch products", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Showall> call, Throwable t) {
                Toast.makeText(CategoryActivity.this, "Failed to fetch products: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getProducts(String categoryName) {
        Call<Showall> call = apicontroller.getInstance().getapiSet().getProductsByCategory(categoryName);
        call.enqueue(new Callback<Showall>() {
            @Override
            public void onResponse(Call<Showall> call, Response<Showall> response) {
                if (response.isSuccessful()) {
                    Showall showall = response.body();
                    if (showall != null && showall.getData() != null) {
                        List<productDispData> productList = showall.getData();
                        products.addAll(productList);
                        productAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(CategoryActivity.this, "No products found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(CategoryActivity.this, "Failed to fetch products", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Showall> call, Throwable t) {
                Toast.makeText(CategoryActivity.this, "Failed to fetch products: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }



    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }

}