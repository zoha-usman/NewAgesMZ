package com.zohausman.mycandycotton.activities;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.mancj.materialsearchbar.MaterialSearchBar;
import com.zohausman.mycandycotton.adapter.ProductAdapter;
import com.zohausman.mycandycotton.apicontroller;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.adapter.CategoryAdapter;
import com.zohausman.mycandycotton.databinding.ActivityDashBoardBinding;
import com.zohausman.mycandycotton.model.Category;
import com.zohausman.mycandycotton.model.ShowAllCat;
import com.zohausman.mycandycotton.model.Showall;
import com.zohausman.mycandycotton.model.productDispData;

import org.imaginativeworld.whynotimagecarousel.model.CarouselItem;

import java.util.ArrayList;
import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class DashBoard extends AppCompatActivity {
    //Button btnlogout;
    @NonNull
    ActivityDashBoardBinding binding;
    CategoryAdapter categoryAdapter;
    ArrayList<Category> categories;
    ProductAdapter productAdapter;
    ArrayList<productDispData> products;


    NavigationView navigationView;
    //    DrawerLayout myDrawerLayout;
    private ImageButton navigationButton;
    private ImageButton cartButton;
    private ImageButton wishlistButton;
    TextView CartitemCounter;


    //    public ActionBarDrawerToggle actionBarDrawerToggle;
    DrawerLayout drawerLayout;
    private MeowBottomNavigation bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDashBoardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        final Toolbar customToolbar;
        customToolbar = binding.include.customToolbar;


        binding.bottomNavigation.add(new MeowBottomNavigation.Model(1, R.drawable.ic_home));
        binding.bottomNavigation.add(new MeowBottomNavigation.Model(2, R.drawable.ic_category));
        binding.bottomNavigation.add(new MeowBottomNavigation.Model(3, R.drawable.ic_cart_white));
        binding.bottomNavigation.add(new MeowBottomNavigation.Model(4, R.drawable.ic_profile));

        binding.bottomNavigation.show(1, true);

        binding.bottomNavigation.setOnClickMenuListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                // YOUR CODES
                switch (model.getId()) {

                    case 1:

                        Intent homeintent= new Intent(DashBoard.this, DashBoard.class);
                        startActivity(homeintent);
                        break;
                    case 2:
                        Intent catintent = new Intent(DashBoard.this,CategoryActivity.class);
                        startActivity(catintent);
                        break;
                    case 3:
                        Intent cartintent= new Intent(DashBoard.this, CartActivity.class);
                        startActivity(cartintent);
                        break;
                    case 4:
                        Intent profileintent= new Intent(DashBoard.this, UerProfileActivity.class);
                        startActivity(profileintent);
                        break;

                }
                return null;
            }
        });

        binding.bottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                // YOUR CODES
                switch (model.getId()) {
                    case 1:
                        Intent homeintent= new Intent(DashBoard.this, DashBoard.class);
                        startActivity(homeintent);
                        break;
                }
                return null;
            }
        });

        binding.bottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                // YOUR CODES
                switch (model.getId()) {
                    case 2:
                        Intent catintent = new Intent(DashBoard.this,CategoryActivity.class);
                        startActivity(catintent);
                        break;
                }
                return null;
            }
        });
        binding.bottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                // YOUR CODES
                switch (model.getId()) {
                    case 3:
                        Intent cartintent= new Intent(DashBoard.this, CartActivity.class);
                        startActivity(cartintent);
                        break;
                }
                return null;
            }
        });
        binding.bottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                // YOUR CODES
                switch (model.getId()) {
                    case 4:
                        Intent profileintent= new Intent(DashBoard.this, AboutUsActivity.class);
                        startActivity(profileintent);
                        break;
                }
                return null;
            }
        });
        try {

            drawerLayout = binding.myDrawerLayout;
//            customToolbar = findViewById(R.id.customToolbar); // Add this line before setSupportActionBar(customToolbar)


            setSupportActionBar(customToolbar);
            navigationView = binding.navigationView;

            setSupportActionBar(customToolbar);

            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this,
                    drawerLayout,
                    customToolbar,
                    R.string.navigation_drawer_open,
                    R.string.navigation_drawer_close
            );
            drawerLayout.addDrawerListener(toggle);
            toggle.syncState();
            navigationView.bringToFront();
            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    int id = item.getItemId();

                    if (id == R.id.nav_home) {
                        Toast.makeText(DashBoard.this, "Home is Clicked", Toast.LENGTH_SHORT).show();
                        Intent homeintent = new Intent(DashBoard.this, MainActivity.class);
                        startActivity(homeintent);
                    } else if (id == R.id.nav_categories) {
                        Toast.makeText(DashBoard.this, "Cat is clicked", Toast.LENGTH_SHORT).show();
                        Intent categoyintent = new Intent(DashBoard.this, CategoryActivity.class);
                        startActivity(categoyintent);
                    } else if (id == R.id.nav_cart) {
                        Toast.makeText(DashBoard.this, "Cart is clicked", Toast.LENGTH_SHORT).show();
                        Intent cartintent = new Intent(DashBoard.this, CartActivity.class);
                        startActivity(cartintent);

                    } else if (id == R.id.nav_orderhist) {
//                        Toast.makeText(DashBoard.this, "Cart is clicked", Toast.LENGTH_SHORT).show();
                        Intent cartintent = new Intent(DashBoard.this, OrderDetailActivity.class);
                        startActivity(cartintent);

                    } else if (id == R.id.nav_PP) {
//                        String url = "https://doc-hosting.flycricket.io/mz-clothify-privacy-policy/02de47f1-bf1e-44d7-afb3-9488aff7b3e7/privacy";
//                        String url = "https://doc-hosting.flycricket.io/gull-rung-privacy-policy/b7ea1c7f-c81b-484d-95bd-52d6fd19fc53/privacy";
                        String url = "https://doc-hosting.flycricket.io/new-ages-privacy-policy/d2785418-cfcf-4ca7-a2f4-20aac32ce7bf/privacy";
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);

                    } else if (id == R.id.nav_share) {
                        Toast.makeText(DashBoard.this, "Share is clicked", Toast.LENGTH_SHORT).show();
                        // Handle share action here
                        shareApp();


                    } else if (id == R.id.nav_rate) {
                        Toast.makeText(DashBoard.this, "Rate is clicked", Toast.LENGTH_SHORT).show();
                        // Handle rate action here
                        rateApp();

                    } else if (id == R.id.nav_Feedback) {
                        Toast.makeText(DashBoard.this, "Feedback is clicked", Toast.LENGTH_SHORT).show();
                        // Handle feedback action here
                        showFeedbackDialog();

                    } else if (id == R.id.nav_profile) {
                        try {
                            Intent profileIntent = new Intent(DashBoard.this, UerProfileActivity.class);
                            startActivity(profileIntent);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(DashBoard.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }


                    } else if (id == R.id.login) {
                        startActivity(new Intent(DashBoard.this, MainActivity.class));
                    } else if (id == R.id.logout) {
                        startActivity(new Intent(DashBoard.this, DashBoard.class));

                    } else {
                        Toast.makeText(DashBoard.this, "You Clicked Me", Toast.LENGTH_SHORT).show();
                    }

                    drawerLayout.closeDrawer(GravityCompat.START);
                    return true; // Return true to indicate event handling success
                }

                private void rateApp() {
                    // Code to handle the rate action
                    String appPackageName = getPackageName();
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                    } catch (ActivityNotFoundException e) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                    }
                }

                private void showFeedbackDialog() {

                    // Code to show the feedback dialog
                    AlertDialog.Builder builder = new AlertDialog.Builder(DashBoard.this);
                    builder.setTitle("Feedback");
                    builder.setMessage("Please provide your feedback:");

                    final EditText input = new EditText(DashBoard.this);
                    input.setInputType(InputType.TYPE_CLASS_TEXT);
                    builder.setView(input);

                    builder.setPositiveButton("Send", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String feedback = input.getText().toString();
                            // Code to handle the feedback submission
                            sendFeedback(feedback);
                        }
                    });

                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    builder.show();
                }

                private void sendFeedback(String feedback) {
                    // Code to handle the feedback submission
                    // You can send the feedback to your backend or perform any other actions
                    Toast.makeText(DashBoard.this, "Feedback sent: " + feedback, Toast.LENGTH_SHORT).show();
                }

                private void shareApp() {
                    try {
                        // Generate a dynamic download URL for your app
                        String appDownloadUrl = generateDownloadUrl();
                        Intent shareIntent = new Intent(Intent.ACTION_SEND);
                        shareIntent.setType("text/plain");
                        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Check out this amazing app!");
                        shareIntent.putExtra(Intent.EXTRA_TEXT, "I found this awesome app. You should try it out!\n\n" + appDownloadUrl);
                        startActivity(Intent.createChooser(shareIntent, "Share via"));
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(DashBoard.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                private String generateDownloadUrl() {

                    // example using Firebase Hosting
                    String projectId = "your-firebase-project-id";
                    String appName = "your-app-name";
                    String versionCode = "1";  // Replace with your app's version code

                    // Generate the download URL using the Firebase Hosting domain
                    String downloadUrl = "https://" + projectId + ".web.app/" + appName + "/v" + versionCode + "/app-release.apk";

                    return downloadUrl;
                }


            });


            binding.include.cartButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle cart button click
                    Intent intent = new Intent(DashBoard.this, CartActivity.class);
                    startActivity(intent);
                }
            });


        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

//        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        binding.categoriesList.setLayoutManager(layoutManager);

        binding.SearchBar.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {

            }

            @Override
            public void onSearchConfirmed(CharSequence text) {
                Intent intent = new Intent(DashBoard.this, SearchActivity.class);
                intent.putExtra("query", text.toString());
                startActivity(intent);


            }

            @Override
            public void onButtonClicked(int buttonCode) {


            }
        });


        initCategories();
        initProducts();
        initSlider();
    }

//    @Override
//    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
//        if (result != null) {
//            if (result.getContents() == null) {
//                Toast.makeText(this, "Scan cancelled", Toast.LENGTH_SHORT).show();
//            } else {
//                String qrCodeValue = result.getContents();
//                String expectedQrCodeValue = "NewAges"; // set teh qr code value  here
//
//
//                if (qrCodeValue.equals(expectedQrCodeValue)) {
//
//
//
//                    Toast.makeText(this, "The QR code value is: " + qrCodeValue, Toast.LENGTH_SHORT).show();
//
//                    //Toast.makeText(this, "the user_id:"+userId, Toast.LENGTH_SHORT).show();
////                    String studentId = user.getStudent_id();
//
////                    hitApi();
//
//                } else {
//                    Toast.makeText(this, qrCodeValue+"not same to Me ,scann the correct Qr code", Toast.LENGTH_SHORT).show();
//                }
//            }
//        } else {
//            super.onActivityResult(requestCode, resultCode, data);
//        }
//    }

    private int getCartItemCount() {
        return 10;
    }

    public void onBlackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    private void initSlider() {

        int image1 = R.drawable.landslider1;
        int image2 = R.drawable.landslider2;
        int image3 = R.drawable.cimage;
        int image4 = R.drawable.ckids;

        // Create new CarouselItem objects using the image resources

        binding.carousel.addData(new CarouselItem(image1, "Slider 4"));
        binding.carousel.addData(new CarouselItem(image2, "Slider 4"));
        binding.carousel.addData(new CarouselItem(image3, "Slider 4"));
        binding.carousel.addData(new CarouselItem(image4, "Slider 4"));
    }




    private void initCategories() {
        try {
            categories = new ArrayList<>();
            categoryAdapter = new CategoryAdapter(this, categories);
            LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
            binding.categoriesList.setLayoutManager(layoutManager);
            binding.categoriesList.setAdapter(categoryAdapter);

            //make the Api call
            Call<ShowAllCat> call = apicontroller.getInstance().getapiSet().getAllCategories();

            call.enqueue(new Callback<ShowAllCat>() {
                @Override
                public void onResponse(Call<ShowAllCat> call, Response<ShowAllCat> response) {

                    if (response.isSuccessful()) {

                        ShowAllCat showAllCat = (ShowAllCat) response.body();
                        if (showAllCat != null && showAllCat.getData() != null && !showAllCat.getData().isEmpty()) {
                            List<Category> CategoryList = showAllCat.getData();
                            categories.addAll(CategoryList);
                            categoryAdapter.notifyDataSetChanged();
                        }
//                        // productList to adapter and display the data in the RecyclerView
//                        CategoryAdapter adapter = new CategoryAdapter(DashBoard.this, (ArrayList<Category>) CategoryList);
//                        binding.productList.setAdapter(adapter);

//                        if (showAllCat != null && showAllCat.getData() != null && !showAllCat.getData().isEmpty()) {
//
//
//                            categories.addAll(showAllCat.getData());
//                            categoryAdapter.notifyDataSetChanged();
//                        } else {
//                            Toast.makeText(DashBoard.this, "No categories found", Toast.LENGTH_SHORT).show();
//                        }
                    }
                }

                @Override
                public void onFailure(Call<ShowAllCat> call, Throwable t) {
                    Toast.makeText(DashBoard.this, "Faild to Fetch data", Toast.LENGTH_SHORT).show();
                }
            });

            //            GridLayoutManager layoutManager = new GridLayoutManager(this, 4);
//            binding.categoriesList.setLayoutManager(layoutManager);
//            binding.categoriesList.setAdapter(categoryAdapter);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void initProducts() {

        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        binding.productList.setLayoutManager(layoutManager);
        binding.productList.setAdapter(productAdapter);

        AllProductShow();
    }

    private void AllProductShow() {
        Call<Showall> call = apicontroller.getInstance()
                .getapiSet().getProducts();
        call.enqueue(new Callback<Showall>() {
            @Override
            public void onResponse(Call<Showall> call, Response<Showall> response) {
                if (response.isSuccessful()) {
                    Showall showall = response.body();
                    List<productDispData> productList = showall.getData();
                    // productList to adapter and display the data in the RecyclerView
                    ProductAdapter adapter = new ProductAdapter(DashBoard.this, productList);
                    binding.productList.setAdapter(adapter);


                } else {
                    // Handle the error case
                }
            }

            @Override
            public void onFailure(Call<Showall> call, Throwable t) {
                // Handle the network failure case
                Toast.makeText(DashBoard.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

//categories set
//categories.add(new Category("Ladies", "https://www.shutterstock.com/image-vector/illustration-tall-beautiful-girl-standing-260nw-1522937327.jpg", "#5B01947", "pink one ...", 2));
//            categories.add(new Category("women", "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBMUExIVFRIUGRUXGhsYGxQYGx8YGxkaJCEbGyQZGCMfIzMoGx0sJRUjJTclKjMxNTQ2GiM8QjozPi1ANDEBCwsLEA8QHxISHzMqJCszMTMzPTY2OTYzMzc5PjYzMzU8MzE2MzMzMzMzMzM0MzkzNTEzMzUzMz4zMzEzMzw8M//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAADBAACAQUHBgj/xABEEAABAgMEBggFAgQEBQUAAAABAAIDESEEEjFRBRNBYXGBIjKRobHB0fAGBxRC4SNiUnKCkqKywvEzc7PD0iVTY5Oj/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAIBAwT/xAArEQEBAAIBBAAEBAcAAAAAAAAAAQIRIQMSMUETIlFhMoGRsRRCcaHB0fH/2gAMAwEAAhEDEQA/AOsLLMRxClw5HsWQDMUOI2IHEKPgeXirX25jtVIjwQQCCchVAuiwOty9EO4cj2FXg0NaU20yQNJe0fbz8kW+3MdqDGM5SrjhXJAJMWfA8fRAuHI9hRoLgAZ0rtogMlYvWPvYFm0WyHDE3xGNGM3ODfFaOH8VWKI52rjtiVa06sF4BNACQJVU2yea3VbhNw+qOAStw5HsTDHiQqMAqYIkQmI1oYxpc5zQ0CZM8F5K3/G1lgdKJrBCJAbHY0Phum0OmLpvSx2bO2e6S69t1dbenZiOITi02jNLQLRMwojX3CLwEwW1I6QOFWkcjkttfGY7VssvMZpiPgeXilkxEeCCAQTkKoFw5HsK0Egdbl6JlKwaGtKbaZI99uY7UArR9vPyQUWMZylXHCuSHcOR7CgPZ8Dx9EZAguABnSu2iJfbmO1AvG6x97AqK8QTJIBIzFVW4cj2IMKLNw5HsWUDipE6p4FV1wz7isPiAggGpogXV4PWHvYVNU7LwUawtIJFAgbQbRgOPqs64Z9xVIjpyAqccvHigCjWf7uXmqap2XgrQzdnepPn4cUDCR0haGQ2viPddYxhe92TWzJPcmtcM+4rwnzb0iIdhEOZlaIjITrsr1wTe6U9zAP6lsHgrd8Qxrc6HG+nZddHALg2ZgsY6HdbPOUarsevsw0nwtZomuvQ4jWalzHum67MNdSY+4AidaCQzQhbHw7NF1MSIGGOaHFzSwOF6X/JrLZNVtdknGtV0tDWuc+Rc1pLXOvNDASLxk8UCyYzVnjabl4rp2jPma6EWwtIQHQnyB1jem075Ccq0I2ZrdxfmFowNLvqmnbdAJd2Cq5Zpy3McbHHb+rChkw3MiULnhrCXEYl0iATUTZvqpoPS1mZFjxIsENv3iwtaXhgM5ww3ZOeOBqDIFRj0727m/6K7pvnTd/GPxw+3Ftms/6cJ5DS97rl8mknE9VnHhLPSac0U6HHgw3PDob3tY1rXTDQLkEm7sozHiNiFoO0wmxorjZWuhEOMnAvEFrQ58p4GYZKVCSBIqzGQW2pj2RXvhw2a573Nk68AXGQOJL3tpsLiFfb23U9T9ane5y9/wDLb4jc6KYUQNJtGuLHChAhlpDSMDMRHVp1BjOa6UuI6DtNmg2/RbYQiEX2hriZC5GdEZJwImTNzSJ7JLuOqdl4KcZJOJpW0g9Ye9hTaUawtIJFAja4Z9xVDFowHH1S6NEdOQFTjl48VTVOy8EF7P8Ady80wloZuzvUnz8OKJrhn3FAOP1uXqhIjxeMxUYZePFY1TsvBAaBgOfiioDHhokcQra4Z9xQFUQtcM+4rKBVZZiOIRNQd3vkpqiK0pVAyhR8Dy8VjXjI9yq586AGZz7fJAFFgdbl6Kag7vfJRrS0zPCnvcgZS9o+3n5K2vGR7lR3Tw2Z+9yAS5V85LfD1lmgObeOqfEAvXbjnOaxr/3UhuEl1nUnd75LlPzB0VGtVqjCE9pDWwmPZK8A5vTaC5oJZPXE1GWay5Sa3WWWzh4r4ctL4cG2RIYY4s1PRcL3W1kMy39IHklbZDD2QogreaGPOT4YDRPIuhhjuN7Jek0RZ4kOG5toEO66LZ4Buht3V6uO8EkSBIL2kk5LUtkIlqh6u417IjhDNS18MOeB/M0sfhmRgumGXzW6+/5IynGjlnttma2G/wCnH6QZEcJ3nTPQfEaNpBewzNejskCEI2kobrTGtTbGHwWi44uBledMB79gc6cqzMt5mntBPMjCAhyi9B5fQllS5gIrMtc4DtRdFm0MZEsrYN+G191tpaAWmE6Zc+Uum4tFDmQHYBRlJjlf9tx5kY0RaQywSi2UmFEe5hMPohzRW++ZnV4uXsmdunsuj4sSzxnQmFz3PuulKjGhrwwZl7nNoMdUebulbQy5dhxIhY4NnDIuhjgLtwDZdaA2XOZNVstBWB8O9ecG3Hvf0XTa4tgve1pcDKUw1x/lWX5Mbl7t2ebI0lrjGBH1txphtfDYyKalv05hsLocjT/hnZWa+k2GYBzqvnex/B8VvSiugOZdeDec8ioAvggCsyTj9vMd10Faw+y2Z16/OHD6bZEOMgC4VwJCSzxLtUl81sY2B5eKWRnPnQAzOfb5LGoO73yWtSB1uXomUs1paZnhT3uV9eMj3IK2j7efkgorunhsz97lNQd3vkgvZ8Dx9EZLtN2h4097lbXjI9yAUbrH3sCoiFhdUSkc+zyWdQd3vkgEoi6g7vfJRAyqROqeBQvqP29/4WDGnSWNMUAleD1h72FX+n3935WCy70pzlsw3eaBlBtGA4+qr9R+3v8AwsTv0w25+8UAkaz/AHcvNT6ff3flY6m+fLD/AHQMryelPgmwRY8SO6FEEZ8i6KyNEYSZS2OkKNGAXpPqP29/4WJX64bM/eKDmHxxomFZLPZ4UN0RwfGfEOseYjp3GslN1Zbt5Xn9JQYbIdntLogbHdCD7pqYjmvIbTe0NnLGczjX1PzStBa+BDEj+nEcZtBNXMlLI9ArylqdBfa7RAigubZrlxoJq1sKHDeBLEB0NrpTH3HYVGVss44m7x7n0T521T2scxga1ohuJk6XSa7G487S2oGYcCmX250OHBhQS5jmvL5hxIdPa5poZz20oJJZzXw3xG3HavF0PAhpqJE/c2cwcxxWNR97ZGdb14NG9xa6oPdlNeqY46kvjy57voO13nziEOuzLb5BkTia7SZzW20TZYhiwWFrxD1cZhcR0TEfDdMb5C62ebHBarWgSDem6dGCZYHYTl97tkhTecFtdE6U1cS9HvthseA4OMpPiHVk12hrnvl+wlR1re3UbhOW2+BPhXR9pdHZHgFzmta9jdZEaJVDqNcJ1l2rqlkszITGQ4bAxjAGtYMGgbBNc20JGFm0o1lQHOdBdM0m+REqYXrq6pqN/d+Vz3vme14/RWD1h72FNpYsu9Kc5bMN3ms/Uft7/wAIpa0YDj6pdFnfphtz94rP0+/u/KCWf7uXmmEt1N8+WH+6z9R+3v8AwgxH63L1QkW7frhsz94rP0+/u/KC8DAc/FFSwfd6Mpy24b/NZ+o/b3/hAwol/qP29/4UQBWWYjiEfUDM9yw6EAJzNKoDoUfA8vFD153e+awHl1DKRy7fJANFgdbl6K+oGZ7lVwu1HCvvcgYS9o+3n5LGvO73zUb08dmXvcgEmIGB4+imoGZ7lQktMhtrXs8kHM/jRwi6Wgwiei0Qmu3CZiO/wma51Z7fAdbGR3vitD3PixCB1Xuc43RIkuhkGR2kGWcvUaatbn2zScZgLnMD4cO7U6x0rMwDled/SvPx49mdYhChQH61k3OaGkuhlsg+LEcG1bTDgJC6s/m+2pEHLXEh2mGIsN8V0RzyxzXkdBo6rHAUM8QRjN08KItvGGWXumHXdWQb0pVrgACJSQrK+0WIw3uH6cZt+5MGYGDsg8BwI2SdI7ZbmDYzFhRLQLzoj3B7HkXW3ROd5ksOiRITnKhxXWZTCat43xf8JuO7ueSWjNHiIWht0vBnJ9G0rdcMTyz3FbI2eFa3vhxS1hAdFdAY4B14gtDy+UjdbWWcWZpjprVpRkSK57XQmxLpIiOBbDaQ2l0SJe8yo5wA3GSWe6JaX2SG2DDhvLZNiEUiVJL3XuuKGYqSScZqepvO78cforHWL1Nujte2yWgRJ3m3DFDSZxITi0PlOfSLL3Ndm0VbBHgwoowiNa7gSKjkaclxx1ic2Baoby191wtMO4GsleaQ4BrZgC8wYTneNZzl7H5X6WL7NEgzF6C68Af4HzIl/UHdoXLp3ePHrhV4r3cbqnl4pZEDy6hlI5dvkiagZnuVtUgdbl6JlLuF2o4V97ljXnd75oM2j7efkgorenjsy97lfUDM9yCWfA8fRGSznFpkONfe5TXnd75oKxusfewKiM1k6kmZy7PJW1AzPcgXUTGoGZ7lhAdUidU8Cl9a7PwWQ8mQJoaIBq8HrD3sKNqRl3lVewNExiEB0G0YDj6oWtdn4LMM3jI1GOXhxQDRrP8Ady81fUjLvKHEF2V2k+fjxQMJHSVqEJkSI7qw2OeeDQT5Imtdn4Ly/wAw7Y1lhex0QMdHcIQcZmkr7hJuYYR/UsK5ELZFh2ZsSG52ufamVaJlxEN5Il9wJi4Kad0K6DCbGdaC6K8lsSstZexDKbNoNJA4Suodn0c+OGQ2SaS++Xn7WtbIuGZBdQDbliAPs7LPHey1tfEaGPLLr5VdUPlObSTOeRr0sVepMrJfvZ7qPXIkLQD48OJGhBwhtpChxHXnuaCbwBFGic5ZnLFV0ZHa5joAtboUF0O8++0D9SRLmMIwYaEjF0pbUDQ75tiwn2owIT2OdUTDyKXQSORDZXpSTWg9G2SJAjPixbr2jCd3VtpJ4E/1CTSRyliQVV8Xd8a1wyfZLBpezsscSC+BOI7jdiGsnvJM2ltKbhKUykdIPtToNndFLzDAuw3GQ3g0rekOiTiG0VYcSC6AIRh3YheC60km62GadICZGV3DbitlbtNR4sMQ3tESFCeNZFYHARQHdEOMhqwZDCUzI0TWrxPe7s3uc1sNEX4dsaYloZGdabM4kh16TmgRGg7v05DD7qDbsfhO3ix6QYCZQnnVu/kfIsJ4G7P+pajQWhHB0C1tLGNMVrhDnelCLiwzdPrSJkDlUg0RNJQr8MRBLoG46oBxpITnR0/7gpwuNys3/wBMt6ld6hjpDn4FNrzHwZpgWqxw4hP6rJQ4h232yF6X7gQ7+pb3Wuz8FOtOkuxbRgOPql0SGbxkajHLw4oupGXeUFLP93LzTCWiC7K7SfPx4qutdn4ILR+ty9UJGhtnMmpwy8OKvqRl3lBIGA5+KKlHPLSQDQKa12fggbUSmtdn4KIKLLMRxCauNyHYsPaJGgwQEQo+B5eKXvnM9pVoZmQCSRkaoKIsDrcvRGuNyHYhxmgASpXZRAdL2j7efkhXzme0okETnOuGNc0Alyn5paR1lphwAejBZed/zH1lyaB/cuqaVtsOzwYkZ8g2G0uNMcgN5NOa4G62OiRI0SI1rnRXF7iRMtrOTTs2N7FfTl3vXhHUvGgNJWgQ/p2Bz2PhzeIjJO6RNQ5pImBMjHkVro1yIHHWMfFc++Yj3PYSJSuEEXeYdQCVFNKxLzmkmtfIrXrp8P2ju+r1OlbeyPDs8MWdkmEF4ZEYLjRQsgm8ZAjaRsFCarWw7O0Q47DZCXvcDDiOe2bGgzkaioG0SnMzoFqCFtPhiytiWyzQnASe8sNP4mub5rJ09Tit75a2WitINhWaLCfChXnTkTEZdfP/ANzpT6O7lI1Wv+taxr4cOLchuuF8GG10UPLQASXPu9aVQKEZrVastm1wk5pLXDJwoR2hYT4U3bvyd3p6f4f0m2Ja7LCdDAgxbTDvQ7xLZucGi61oDWVINBsxnVbLS9nEC2W2zmdxsRxAP8ET9QS4X6fyheU0HEu2uxu/htEF3Y9hXQPmrZ9TpCzRpUjQ7rhsc6G6VZV6sRo7FkxmOXE9N3cseS3wLpj6O1mHEdKFGIY8zo14ncicCTLg4HYuwkLgVoeHG+GN6JHQNW3J0BniB1f7V1n5e6cfarO4RW9KG4svgUcAGkTydJ4Etsp7VnV9Za8/udO+nqYHW5eiZQIzQAJUrsog3zme0rm6C2j7efkgosETnOuGNc0a43IdiClnwPH0RkrGoaUpspmqXzme0oLRusfewKiYhtBAJAJzNVe43IdiBRRN3G5DsUQXQ4nVPApSSswVHEIKzRIJ6Q97Cm0KPgeXigKg2jAcfVLSRbOOly9EApo1n+7l5plL2n7efkg858f6MdHsUUNnNnTkKiTSHmY2mTZCWE9q4hFiUAGLpbZcMd/gvotzQQRmCMlyL4x+X0dhix7P04ZLnGDImIBQ3WBjJESOG7EzVdPqTC2X3+6M8O7mPA2mBE1hh3SYgcWXW9KZGUscErNem0RoG3Qmm1iDEhwYbXPc8gNLoYF5wY1wrQfcAKYorYtkjNe0Gz3XxNYRFe6zRQ6XVvuDmGZxcHYONFV6+rrW/vEzDbyi3/wFDvaUsI/+W9ya17v9Kfj2GzX4j9QxwewtayHGg3GEASeHaypPASu7ZzXo/l7ZLO7SEDV6mdnhRSHNeHRHk3WXnhpLRSI6czi6khRT/EY5cRU6dnNeT+YmjPptI2gASZElaG7mvJvcg9rh2LUWfRMZ74LdWW62rHuo2X8RyHGpmJYrt3zLjwoEGFaHh16/qgGNYXODgXFs30A/TntwNDs5HE+J3gShWeEwBrmAxC6O644zLZOIYBPYGSoBgE7+peMZ+bLjj5tUsWimse1z7RCESHaYbGw2uDnPk9syAKjHKkjNdO+cliv2JkUDpQIzTP8Aa/oHleLe5crd8S22RAtURgyhBsIdjGtC7Tom0jTGiLriA+I3VRP2vaQC4YyNA8cQnzznL+zZ23iOPsitAaWxGvAAmQC0GYq03q7ZLsfy1smrsTXfxuL6CQcDVr97i26CcOiBsQNC/LyyWW4+cSJEZMh73EVNCZNkJAGglTMr1MvRTllctT1G4465M2jAcfIpaaLZx0uXomkUXs33cvNMJe0/bz8kCSAtoPS5eqFNM2fA8fRGQCgYDn4oqUjDpH3sCHJA+okJKILXDkexZAMxQ4jYnFSJ1TwKCX25jtVIjwQQCCchVLq8HrD3sKCtw5HsKvBoa0ptpkmkG0YDj6oL325jtQYxnKVccK5ISNZ/u5eaAVw5HsKLBIAM6VwNEwlo/W5eqDznzALYeibaG3QNWWgCQHScBSX8y+d13b5qxrujIwnIvfCYN/TDiOxhXCV26U1OHPO8pdGS9b8ro5ZpWygGQcIrHcNW58v7mBeSW6+DrTq9IWF+UZjf7zc/1q85xUY+XRvnfaP0bHDBEjEe8j+Vpb/3CuPrpnzrifrWJk8GRHEcXMA/ylczWdPw3Pyi6N8mdMau0xbK53RjtvsBwD2TnLeWH/AFzlPaLt5s1ps8cGWrex53tB6Q5tmOarKbjMbqvp+I4ESBBNKCqDcOR7CswXAlpBoag7iJhOLyu5WDQ1pTbTJHvtzHaqWjAcfVLoCxjOUq44VyQ7hyPYUWz/dy80wgBBcADOldtES+3MdqDH63L1QkF4gmSQCRmKqtw5HsTEDAc/FFQJXDkexZTiiAWuGfcVh8QEEA1NEussxHEILap2Xgo1haQSKBNoUfA8vFBNcM+4qkR05AVOOXjxQUWB1uXogrqnZeCtDN2d6k+fhxTKXtH28/JBfXDPuKE8XjMVGGXjxQ0xZ8Dx9EHNPnVELbJZWEda0XuTWPH+tcdlVdP+dtovWixQq9Fj4hGzpOa0f9N3auZwxN44r0dKfK49TyGrwopY5jwZFjmvByLSHeSoFh4mHDMK0x7/5yPnpCDI0+lY4c4kbyAXgV6r5g2vW2iyRP4rFZXf3B7/8AUvKqcPwqz8oixW9FhzBHZ/uhJotnCByd4zCtD6A+AbZrdHWJ5M7sMQ3H9zJwzPaT0F6XXDPuK538nLTe0fGZX9OO6W4ODHyHMntXu15cpq6eiXcGiOnICpxy8eKpqnZeCtA63L0TKlpaGbs71J8/Diia4Z9xVLR9vPyQUBHi8Ziowy8eKxqnZeCLZ8Dx9EZABjw0SOIVtcM+4oMbrH3sCogZ1wz7ispVRAXUHd75KaoitKVTKpE6p4FBTXjI9yq586AGZz7fJBV4PWHvYUFtQd3vko1paZnhT3uTKDaMBx9UE14yPcqO6eGzP3uQkaz/AHcvNBjUHd75LLTdoeNPe5MJaKJu5DxKDhXzPtWs0rGFZQobIfO7fMv/ALO5eQsQm9u6q2enbXrrVbowqHxIkiKgtvXGkcgFr7AKuOTSvZhNSPPleaVarMbOfBVambIyd7+U+BRhrTca/wDR1mW2WCz+0vbLsC17G4rMUGUMnBzJt/lD4jZdrCiwm05JI20uBROWZs4bxz7K+SWa3oOORb5pzR1WvCrHyx0n5LRTO3Q90F449MH/AChdR1B3e+S5L8nHStcdv8UEf4Xj/wAl2NeTqz5nbDwXa0tMzwp73K+vGR7lLRgOPql1CxXdPDZn73Kag7vfJZs/3cvNMIF2m7Q8ae9ytrxke5Uj9bl6oSAhYXVEpHPs8lnUHd75IkDAc/FFQLag7vfJRMqIF/qP29/4WDGnSWNMUJZZiOIQF+n3935WCy70pzlsw3eaZQo+B5eKCn1H7e/8LE79MNufvFCRYHW5eiDP0+/u/Kx1N8+WH+6ZS9o+3n5IJ9Ru7/wktMWwQrPaI5oIUN78+q0umjryfzQtmr0XGbOsVzIQ3zIc4D+ljuU1sm7plcODbsEDO6PPyV7EOhEP7SO4rNtoyGN5Pl5ollb+k7fP0Xsnl5iYZQ8E1oxtSsOZ0XcCi6NHRJWyclW0jBAsmjn7XC0sP9EUuH/VKDAb0eXktnpJn/plldLqWu1Mnxax0u5Iw2yhk5NPgpwVmVhN/SicR4hF0YespAb+i/gT2KujDVyueYl735Wuu6QO+DE/zQyuxa/d3/hcV+X0S7pKzj+MRGf/AJvd/oXZF5utPmdun+EWd+mG3P3is/T7+78rEDrcvRMri6Fupvnyw/3WfqP29/4UtH28/JBQFu364bM/eKz9Pv7vyrWfA8fRGQLB93oynLbhv81n6j9vf+FSN1j72BUQG+o/b3/hRBUQMagZnuWHQgBOZpVHVInVPAoA687vfNYDy6hlI5dvkhq8HrD3sKAuoGZ7lVwu1HCvvcmEG0YDj6oKa87vfNRvTx2Ze9yEjWf7uXmgtqBme70XKvnHbhfsllaSSC6O8ZAgw2H/AD9i60vD/MT4ZiWwQHwWMMaG6RLjdLoZDptB3OumR3876eu6bTl4cP0iek0ZN8Zpuzt/TA94pr4r+GrVY3tdHay5EMmPY68JgdUkgEGVZSzVGN6LRuC9eNltseezReMyUN/8pVrC2TArWv8A4b+HmESywXGG5waS1gBe4YNBN0F2QJoq9sM2i0MdouPBBGshW5scsO2G+FqwW59LHKYzSEcXYb/5ZeSLY9DxLTEtGraXGFDZEutaXOdN8NkmgbZEng0o1r0bHdEZZxCeI8RzWthvBa4zmQTewbJpM8gVzx1Nru7olZmfpSza7zSujT0uS6vZPlYRCZrLVKIB0gxl5gOTSSCRvMuSSsfyncyI0utrXQ59ICGWvIyBvEA71nxcfq3syed+FLU2Hb7I4kUitaQMemDD/wC4u9agZnu9EhC0dA/TbqYd1hvMFxvQIwLaUNMVtV5+pn3XbphjqAOF2o4V97ljXnd75q9owHH1S6hYrenjsy97lfUDM9yrZ/u5eaYQLOcWmQ4197lNed3vmpH63L1QkBmsnUkzOXZ5K2oGZ7lmBgOfiioA6gZnuWEdRAprXZ+CyHkyBNDRDWWYjiEDGpGXeVV7A0TGIR0KPgeXigDrXZ+CzDN4yNRjl4cUNFgdbl6ICakZd5Q4guyu0nz8eKZS9o+3n5IKa12fgrw2zmTU4ZeHFBTFnwPH0QaP4t+Godvs5gucWuDhEZEHSuvaCASJ1EnEEUxWj0D8BwYUKIy0thxoj6XgC0MbKgYZza6s7wkcMl71KResfewKplZNRlxlc/t/ywgRCdXaorGGXRLWvIqDIGYOzbNej+F/g+BYmvuufEdEaGudElK6J9ENAlKtZzW7TUPAcAtueV4tZMZCdh0RZoN4woEOGXyLixobelhOWOKq+C1z2xHMaYjQQ2IWtLmg4hplMLZJAKFCB5MgTQ0RtSMu8pdmI4hOoAPYGiYxCHrXZ+CNHwPLxSyAkM3jI1GOXhxRdSMu8ocDrcvRMoFoguyu0nz8eKrrXZ+CvaPt5+SCgNDbOZNThl4cVfUjLvKxZ8Dx9EZAo55aSAaBTWuz8FI3WPvYFRBfWuz8FFRRBFlmI4hZUQOIUfA8vFZUQKosDrcvRRRAyl7R9vPyUUQBTFnwPH0UUQFSsXrH3sCwogqm4fVbwCiiC6QCiiCzMRxCdUUQCj4Hl4pZRRAWB1uXomVFEC9o+3n5IKiiBiz4Hj6IyiiBSN1j72BUUUQRRRRB/9k=", "#5B0817", "pink one ...", 3));
//            categories.add(new Category("Kids", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTk6pbOFl2jhphjqWVvO9XJOwpt8m7BBaAdA&usqp=CAU", "#5B0147", "pink one ...", 1));
//            categories.add(new Category("Abayas", "https://i.pinimg.com/474x/f6/d1/07/f6d107379f33b73e5e2aa6ddb0e60246.jpg", "#501437", "pink one ...", 4));
//            categories.add(new Category("Accessories", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAACE1BMVEXzyJP///+zS4rTRTnzyJLTRTj//v+zS4lRGAfvyJb//vmzSovzyJXzyJH///yxS4v++P3+/PT/+fasR4XUQzbuypq1SIvKQT3JQjT/9vatTonJRzvuy5qrRobJRjXURDtGAAD7zJtLCQC7jG7Dl3RvQTLtmng/AAC6Z4H5y55bLyOvQ4n2xpPipJQ5AADXRDgwAABlOCOSYFP3v6Lji2z04MPOOSzQpYD/7uzw3dunO3/YoaDKfLDSmsBFCgD68d/QpMHHeIrus57y2rnkoHbYlpKuTX9SDACrdVonAABNAACvVXv97vrRXUbusYTJT0TGLx/NKRzPamTWjIvNWVPmr6eje2OVbVG6LiD3ysTy1MnhtIrsvrXPenDcqaXWbmW5TELGkY/AcW6sPjirUUvk1dOdNzSJZErgtdLFhqyuYY+3YmLw2unixdiqLynar7KxcW/Tn4OXVFiNK2WgUWSOO1uUUFTWpIbHi33Tjb27lJGPP1bUerSzdZ6vYl/GIhPlrNjGZJ+ZRHHDk7B1JkPhjsmzWntQGR+UWnK0epROICtQABl5QVNrIzW+aomDMU3ajq12NTd3XVqdU4FZDCrvlZB/MCezM4uhlpJVLifEk5fVco7myNG/S3azSGC6SFB0JSCTOUXrqrhiAwDXclSvRy3AfF7YtaHdbXx2EgDFsrC1Z06qUz/8tqLheF2pgXyaU0FW7bhrAAAgAElEQVR4nO19j0MaZ/L3riwQ3F2IslCEKNmYGPZ2KdeiqASCoNC7GtEGY0zQ2GuqqVxiTZOc2sYmmqvt3X3P9nt3yfX6prlem7v20jZ9/8R35llAfiwLQpqmfTuJKD/E/TDzzK9nZh6K/qkT9UNfwPdOPyP88dP/PwitplbfqeU3KJD1Sb2RSnmEcHntnV0tUGfh2qztHS1R/mrg5mBLVPygCjzsTE4+1wpNnjDRJnjT9gFHC2SxOAba1Y98xC3bmqXu7m73yMEKhBemAgFBgP/kJlB5U+dhwRuYukDeZ8DC8AwFX00SzwyQ9xkJO51OlmWd8K/8RvuRioedzvBIOcL2yUCP0eD1GgwGL/lf+aX/EPwPePCTtzp4iqEoBr6aI4Z3kAtyO81tzZPTbHO6D5Yh7HzOazAamiajUTC4ULzaLXCRFNcsB+GT4S34Pia72dy0kNpsbeY2Z3clQsFIGNI8uax5hK2RYmlHRWNvY9ua5yJr00LYCg/hd415hE3LZ0FMCQ9pu5ltRUxt5jbbzwh/RvgzwmcfoRHuGr2CF74MAj7gNeIrAkaDls7VR8jxeMvzWk/9YAgDhrwp7wkANiMxeV5jaCqEuPeHEOwjuAA8/vAs8dBrEBBX6JWQ0RgQjMDAwFQo5B/yhzRdAx2EDCUiFxuV3qcopV5AFTo9fGJqOjMdMBiF6eEzs130cCgU2h9CynF2ZuZstkocf3CEgtcQCk0N0+2z5+jzAAp+PH+apudmz50J7QchI57NipQ0gxBr8LEM/FPkoSFwes51nqZPz9FDs8YQoEtC+JCch0eE/fBw8CgoGl46K2rjE7ksJ/4gCA3e0DB9Zg7iqiRNT7oWztH0q8PwBd9Pg9DiyqyLUKEYhbskopahzuJqLD7J4JPIvqNnZ47OAHquMYTgVIPXyYLPaiZP1/oUGrOHs0P08G9o+txrgOlMZyc9dLGd7loZomlPta7RRgiBojiT5XmOo7izoE/zMDCAxBCLy/aeHUQdNNi7J6h6CM1mDBnNBJ0N4bIQJWl66I3ZQ0A4BOiGXqfpzNwiLEG4cx7uDL0SAgsiNICQV/jsDIDhePguckV7yEmSxQLwerMUPsaLZxtDSAKjNghvZTkM1C07EayNbRrhMN35W5ruWuqiL1wAAX3tTVVk52b90wFj5arVREiJlyQFDX72ksQUFc0gKNeZ3qNZ1YSAI8D3Apf5BngIsa0ctuc2oyNvAI0s58Jhp83cHA/hkqdAzfy2C75Ai74K3y+CgL52DhlKD78iNIKQsvQO4oUzgzMSzxfXGq8mAXgEiGsUecgV8OshZJ3h3MjlU/QenbqyHHY2x0O4MwVqJoO8A2X6W1Va6RVA+roVENZdhwxB1isSh+asBEA4pcgnZBxxdThM6eA6LIpwTYSw5MKbl/fAmfLpy1MjbmdTCI3eV8A4nACUJy7QnSCgc6B1hpbgaxV+nvLq85D4aOLgjMhzuApnQIuCMFIK+cbwnMjjIoUXitnBwd4ZC4BX9BCa4a6z+wqtSadyMlshqo35NCFYc+dPEGU6NKwK6FwGvgBtRgjoIwTm8OLRGZFgVajeLK9wHAciOcgjt66+FeSJq8r19g4ezYq4FnURAjntyECNvLOJPpgDlWPbL0LwSedVhg1fpBc7VQHNALrVIczM1bGHwDfp7FGAB6IJIjk4yCk8L2Z7r1+7ClCk6/LOOgouqli0JSCwPFcHYfgKbTWZrBoZcav1VJjdPw/BbwM3BpXp0MVz94Gb8BO9NER3vQuYp7wVIVQlQlCgvVkwgJg840XR0gv2YvXGteWo+y1w4X63HLU5t9c5UDESWX+YJ62D0LmsotHiopUekZvQNIJ3EiTgXSt9f6gTrOGbIKjtwNH7sByTVc53FQ/zKVNJyq6tr66uvzi4dmNLjkSWN+zr0vVc5LbN7Q5fl7K9DImsSiKPGgid4ct5kdQgE33Kzu5bSiEoDIFsvj00PEwPD+29+eow3fWqINSzh4y6Gt8Z30bLLG+vf3hz8+bmRi4sb78lb0U3oxsbG7JvRlKAdRbie9e0hzbQM21Ot8lagKNFm0SfmveDEILgWwis/b6VXtx7104ipIZKqmEPufGtSPfyxkbEGR+PbETcuWh0w769HMlFcjZ5w5a6JPEiLkduL/6vQmgGRw1cmZzOnhQ8E+0G94bd+1QaiYCNxlvD8LuLQ7T1fsmbdaKQBupJaRFh9LY9Gg5H3Te2nVs33e/dDG9tpNybW1vRaC6yZQ9eWl0loYei43mjH2p2RmriI3QFDD+7p1AbzEShU0MDC3EZFoQDv3mqQ+Aannd2O+q+ndtY3ty6vm5/LxzN3YnIUTm3ufVe7vZfb4evr28DzBurWfBZmVo+DV40WPtlvX1FEyCE17PsfqQUUxhg8tESLnaVvZ2GkNbyS9fCkQ33xp3by1ur2d8v55a3ovaNnDkcSb3XnbvtvjGzfTN3M7UVuXH9V2JNnwbiB5bt3nlTn4dDSZ9dZve1Do0QPoDJX4TrLhFSZOGJxmP8q+GbN93Lbjn65/ePXXrh/Q9AveRk33X3zdSdOzfeyV61uyMbuY3c7fBqbb+UNbPdPr80oL85HOOlBGDcn6bxChm68z7qmvI30wjxa/Hwqntzc8O+8Yf3Z7K9M73ZS3/cDqeuvRW8+v7hY5cu/eLSai5y020D2NfWaktpG5vyg98+QKOxL1OkJrrwwPCb5w/xjORPOSHCAoXT6DoEk38fFMvQYtmbdnoaR5jdBqbltg8Pzjx/8sjh40d7/7T91+3c9u9fhOBwZvDq85upyHtbGxF7eI34cNo8HAcPDxHCH7fSdKW5sGIFwvlbU/Oj4FsEU8BxJ8aMDcUWhtB0F7JvcajsLbWWYS0p5de37XLug5mZ4weQnl879iEsuw339eOHTx45fix7fDmXiwJE4GEtKWVTQXAIFEdMBVfmtZlMecjnQ97QcwmJ4xPdbahSG0PoNQie81iA8Kj8czu3H4TS2ur61QNrzx/I09rftrYiEbf7wyNw5+Sl3v9xb0Td7veuZXlO2/Nm5STPMdyo9TfnrRX8MxXvnE+CagjMBnlF3GXb9iGlRtc5QGh9VP7GFxrOlzLi+vj2+OraC0cP5wE+n/1jbms5txHd+PMRwtN/RDft4eXcOwCiGiFJWYSDYC5HrfT81OkLw1q6Zmju9K27IYMwOzcKTnzcjkxsGOHs3EF1GZpK9Fgm1Og6ZNbC4a0t+cNjvUfyCI+vHQapDG8sb6S24e6RmUvXIu/BOlzdM/lVCBPg8YCILgiB0NTk/IXzJWumc3j4XPJVIbSQnApNDtOj4OTvOlH7Nrz3NHWmK78M95ho1VKl2gjFVfl2BLyXXwweL/Bw7Y/LYbQP0e4PVYQvXk/ZwQUHF7bGOnQmCULrNPxZISCEpm6FPNOnT8+fPj3tmVqYdnmn5zOZ6aR/aPjNhOQYNbP78WkMoTNg7x91lgmFabLhfQtxPBIJb7zn/ttgHuCRY70fgIcT3diSb5xElvYeW1/3Zdak4irU0DSRUVKBkpkSvOhKQtCj7hOholiYBv9RuJU8fXry1q1XQs/N3w/vy2szhE5g2LTHPlRkXSFvgwgZcTsXcUfv2P/wgsrEIweyB25E3TfZ3E33n1XFc3Lbntu+ymPmuJY9DF8e5R0ddGfyuVAoAFYaS2Jwiw/iG2FyXhCE5/yn506cmJvze0Kuj+z7RJjpHO4scZdQew3f2gdC53IE1pn7z2fXjh0/fvxS9tj//h78VDc44kTRDF764GZu8713MItB1cpiOHOmActoB1zjucyrs1OvoBowkj9pEFzzoZBn7tUz8OkPUI7YfLyb3SfCefr+fQgPL7QPf/xxXlrBWDQspRBPLG+FwTP724Gjg4PZ3vc/XL16ww72MPXiyeePH1s7+z9u98bWxvYaVXTaNKIncLpjo44Y0XVD5y5kpiddU7du3ZqC9bienJ3vnJ+n22MOy0DHqZFcwfVuFKEwbaKTnV2nQ/PvHz7y/F+IFrug4ZVqImQoKbUR/et7YP7k1ez7f/rjnz5IbYSv37hmN5v/PDM4OHj0hQ8gZtzacMtXeV7NvGkibJOXTXTHwOhAR3shCO4aGhpSiwXb6aFbZ2KO0Vg7fdktt+0XodHTBctwzhVaeO3AyQPPv33uHE3PC43sAZOwdjDsBqcNMIR7V+0bm274CVbdcmp7M/XB395/4dLvo+6taBhesk4xhVSbVnzYJucugxzGYgMDA7FYR0eJVeyIxc5M+WMgwwdHMP29z/jQYAwNmR6BefC+dnfy4r3Xp12ntf1ubYQUd/TqW9sQ8kbe8YcjyxvRiHv55rJ7ORyNujfsy29lr0Uj0WhkM7fxK4bTReh02qN4vdZ2QHQeuFmgGAA+cysD+N5wO1mS7tgfQsPU8NDisCvkXZgWQnfnzng8ndZJQas4rBohriyGEbPr199ZldbDEBhGN/4eyW1sR/8Oyid1c2u7Nxzthge6b29cF/dyUVqZKLhw2X4nn82v9Gu65k6cGnGHWZsNHbb9Inzl3OJQ19yZ1w8seScXpk8veDo7XcZGNI2aiAJvH8MCis/IG7mwezm6ueW+BnzLhW9uRsLr13KRcHdUdneDW6rUjIDNbWS30CnjnoVGGurUG5thubDp5twvwtAFjJwWwXG+t7CyNBmapIdDhsYrFRQGE8GUAlGUHI3iqpNvXJfDqcjyTbCUa9dlQOuWt9evkg2M2jy0qXuirAx6eeTK5VOnDpqADp46dfnKci4sO82kkjG/q7g/hEJm2Nq5+A80zi8dOP6bTAbiFA0ZrbUzgywEceUofu16uE2ObN6+kV1L2W5v3e6+GXlHCt6Q/x4eX7dg0pvha+lSG8lEYcCAm7+AUu7udueA3PZwGOABkzHJhgIKKPeNcKH90V9+ffxl4jkf/hjc07mQZu1UvZooXlm/YbdFbqzx3Go3iKn92vUsz2fXr65JfHkhSoP7+Bo7aqXUOEIs/O1a/Pgvv0A38h9gEM+ENMtQ61Z98ZR01Rde5zHg2H5r/SrutCm4O8NU1No0WqmgD7FhhAEXxCdnzmTmpz0Xlz774h+L1kxIyxw2gBDEUOpVGAVuJbLrBDLMqdsxTDMInxAPAWIIKRAwGgM9Pa6V05OBfWiacowAEtmG6V/csKHInhNHVZTZPF2EEJkESNkeOtv4HTx5g7D/yr38tSO31BueUSgI63mO2avQ+IF4aMzfGCseagZhER+jFi0Uvipe9HN96c8If0b4k0bYCv0oEHqNLZDXKBCEJgvab6bhiuBS4nnix+a7gsjeb5OETTNOthxh13NGQwtcxIpwF5ZJtFsaq+bWIo4QL5FPys6aterVGmWhRlcQ+CpG8q94Yyy7qX649NW42eghqXEH4YPKj30SegJADlJQ4nbaWAwX2LaKm+pHWI1HnGbWbSpDSJ+YCmg6nI2SEDpB3mcAwRUZsi9SlyGlboWOhJ1txSLZvWLZvUf0HsaAubL/kLZemHS1Qh4ECFfWMeCwtELYQ4qJ54Mjbnsr5B4xVSBEPWhtmsi+hpW24n6e1dreAuW30Mh+b9O90+QXK/uAnwA9kR7sJ9YRXqQyhKYmqQjOqlVYt38y5dnX9PXQ1r0rKenHb+3iCFDTE+NB8yJafIf89z0eWjs6ml897e1kHeL6MR1s9qM35XmnftitrOb29vYirgJC7KNvVQeipjFFNXRgd/Gm3nP5PnorXk/LOrkcIdgxqoUO7GIffTSMblN14XWjVLBjA3wL10MpDE8NlCO0OqgGu+dq+JQMRfroTe5W/GUk1k2WkIPR6lZsmADKIWsZwg4HQzXlLhfekWEsqj/ZPPvyZCe21cIzzY8tIBfkaK9A2MK7qe9YiAlaRogLsd1S3V26v+vhnzRCCqMeMBbddZLRdYklCK2W1gBSlFKFsCWpYJ4cQuShyWS1tLJoyG9WIjzEt6Jo8MNRpbRb66LJvgpEChi2kzogXYToNiBCjb+DW1kM2Q2of03VCPdKWppASOkgZCHQw0BI3eGrO+6igFALBM+QFjBFefoIdXkIXMPdL6xHZyvbd/aHkFI3B/ZqU54NhLi155SJ24J1yvUWqg5C3EfleDGBXVPPEkJgnH08nkn6/f74eHfdFJoOQuxa4PlkONmIon1669DM2uPJhEJyMLyUTMkaqBrlIdq5RMqZSjSgaJ8KD0HDgJM6nlzP5hNNDM8Fd1jzXs3EvhHy0i6s5XHpGZFSFpsGfWfWJfChRgdiA6NgA5TgOEs6DJpAiDtywU2Zddr9zwhCsH12ACgyjgEyh43u/BKUfcIOEG01l6MuD3lqLiqb3Wy8/jU9FYQ2s3MHOEiNqviADn4S5Km4rGcydHUpz5y/49zaYn1i9bPfL0JKW9OATliV+IG9/Ij1VFwEJrbpQNSVUoq/f0e22Zw+6Wkj1OQhy3Ynk35+tL3Y/AFQ30gy0g5rq2009HjII0In2yb7asygeMoI25zj38ZFR1FECZ3ySXxGbk5KQU8x95fBbXhWeNjWncwk+BhdTpsJPqm3EHW9NoU5tyy3AcKnvg61pTQVjCujdGmuGMXUz/vtOu63DkJOYRSQUvMPIaWUJsK4P8lUsNBKX1knCGvGULo85Knzd2SzTd59Ntah3R8POsrzzKBtrqwiwtpOjb7nzc19/n+A4s1LKaNOVqG4Mu+doYq1WQpTHOFRcA5JU3o5QhJChINxaaAMIG7hXFllks0ipKixCQ/S5FiTCNFxBA8ea+kw2FQTjyD9TLE4kmPIuBlsnyeDO9DLV2PuSoS2tlRwVazUM7AO1/kMW3t2Tp34sC9kMAoGIdDXFEJSgAXfAaqiYCSg4ENqpALywanbu2pJIXkWvhiyIVqNEPdidxIZS0cVwhE/OjVNIyTdFsYmEWLk7D9x4k2gOaQvsxZ1DAkZtIJg1cFr2Wxibg5egy9884Kf01qHNgDpSyQBYdkWC6zKPwSlcWdtRfO9IgQ04ritjZWB3FtbkeWRK/fPBR0KltnlS7Z5JXvm/pU3opHI1pbNJsuszYaRjAZCiOzjCb+lna4gsPjgeuuE+t8rDxleSuEkJtb86QNCn366OXLl3JeY4UJmSokLV95Y3ik8SaI8NiXx1ZoGrQHw0M9VSemVOBh8m7l2hKiLkGlVSikpBS6R7dN/3vviJUKf/etBKjdy/0tMbon+N9/YSD1Y+gweP/LSS1/c++enNjNrSwV5pQohNv+bd8oQ5qV1MyGO66Zq9BAyhIeG5hHyHCBkzal/vnSgSC8tfeoMR0cy/uTu7Vz4wb3SpwBimzmVr9SuQgjY17kSXUq2Ty/7qES4aYQqD1tBSKTU9uCLA6X02YM2uRuWpk12PvjspdJnvngAEWAqqBaOVlp8lg0H16XRUjVjRRYyu/rZtvrrsAWECkSnoAX+WQbjwIF7n4JSsdtttk/vlT9x8p/gIsYlbZ/GbJaTfqloLlQhHYkzfntLCI2tIVR4KS7vvl6B8KVPMV0WT7EPKp44sBSRdyUte0gQOncTWWagFOHlHTQVugAbWIfepi0+SRP4w5HfVeA48KA7w/Bi0l6NcFlO8pSWlGKOm7X7/WJhJeLm/OXtoBivlzCtsw5DOAheCDVrLeAtgqnIu1U8tAfBeQumPq144sjry+EgNhXUjIATWV6dFUB87vGgmLHj3gXE+G2suodRVaCnn2vr/ZVKOIdQtcMcsVVc1WaNtqbB6XDxrczhciD3nOjK80zc/FnFOvxtDgI1dLxrZBO74wmJyrd/Xt6MB6UMrGZnvkbSSXZqbJVTAfVy3oz0y5MnDwOd/DX2DaMJ40Qkjc2oGroU/ifCn5fr0pcehBPYbccnUg+OlD3z8uduP0+ikRq5Nli/fljco7Hh+59kgpQUD3fb3eM7uz7f7s54ym53yqza0dQwwmN5+gU2uzHZSy8QOpatzp/W8GkYMhfo9VIgL/3LHBeJseQz5n+VMzc6LuV7DGpkE1m7L5kVSWTCcVm/L5MISpIUBMJv/owvJVdmNHQ1zWAB4bGjeKmXXszTWa4KYg1Ngx+UP1XKxCP/SnVnSAck6ppPPztZxsJkfhhZjZ0ZzOrbd+NJfyLhz2YlRQwm477xa9fC4XBqfDfjD0rB5E64YR5SVHH+xOFeiOzE4ydVOn5MrNrJ0Pa8OQ6YL/oin39R4OLh1S37eDiOEyyluH3cvvtWcZG+nNnYkfBCamoaMoHD2cba7eFwHOBltu05cOcvI4GDG7Ff20lKon+nG4tlzQ0g5EsQ4nDUoqw1iLDwNqBOP3/ri5cPH375pbc+2rInpV05LvJURt6Rkvat+P++fBiW+8v3Pt/YThSkR3f/EDSnPSMF49vLV0rnVtL0wct33KkkfnRt+0cIqqYUYdVrayOEICkx3r3x+eef/OHzjyLhcb8IKgbWm7STSvCcf9we+eiT+Oonn3/khvuFMQE6CFFhgpwHt0cQXmXx4qk3QEDQSBa3958CQpA6Kbm7bU+lwilfEv1qPhgEm5AIYoAo+X3bqVwulQIB2xsMROlWKjh3JGn8MmZpKkoO8d4pd4YKpvYU6vePELUSxENSMAEaDzM2ag8k6ejlGMxuwFOgEkFulUKlmB4PgTlyhvdfoen81LwiF5Gf8B88HT4um58eD0HhqJM4sVsQkzTwIxY/gESicedJMkpV/8W+Cv1dbjMg/BInHpms1ooaWzIH6Q8EIfvUEAKzcLOWyB5TUj+HY2JJKkct9Sirg6tTqeC843B0FKY6FTlYHHL3iTj6kfwUNU0zVKdiyLkcswwUcJXwT8W4GLTElp3sM46Qqo0QC4a6T8VwG9hUjo/cs57PHoqd6m57irq0KYR6PLSBmOYOdozi/JEyKQVqjzkco7GDm+zesIAfIULMfztzl8kAlpLJJDjGYwBgxxyPLofb9qZy/wgREu/UaY+ewmErxbEkAA4Bgz1MdJ0Kqx1LP16E5EYO5522/CF55AIOXlnuTi3nSuP+hhFSyjODkIiqGSeqh3N33rh8+RQhcL6jODVebRj88SNEsoEL7lRn/nfj0A4ZT8drq0zwN4qQeoaklAgpzmpGnWMjQRVyFQ0EydKUJ98ajp74ZwshGY6jtgfm219xIoutjRx0Z24GIe5j7hNh8wBJkK+P0KZa9BIwrIrVXLmVqItw8BcFOgqusXj4eJ6OVe/rV1Wy1y9n1CF0UUm/xcEn0I2gl8VQM2tI5GCeigbUeghbwFhE+CT6LdSOkoYuR+81Pw2EevTMImSfDELu+0L4ZNZhqwjJr2r0zDT/jqQKR60N0jgRZX/kdOPbtLem+YAq+57oAVD4SjNzAghhIqfQR0+2JMrdlH10CmH/IX5UA5SS74hUi5gqbijdh8nEg4r+w1Z7NqV8D2m+j75Gv2hDffQHC9dzqPnL4ap6SNVotAVS80vW/IHaLbQC08VER0tt/dV9wJgzabF72lrjiJQmCAeTt3o5xV9/YhMHKueJt0CmJ3CW/R4V+/FbPK3dVORgeztpe4ebjoqbjg7tRzqKd/JxsYqzs7Orsznq6upsL0p7AaFpxN0KgYZQ34d0vbdygPyAVe3GPzHpaYUmTxSGdBcQktPamyawD6TL3EQPcDjnX62BU2/40jtMqY1hNJ9Trc6JKXI2fZMUCASmTpQjPIgTb2y4qW4jJwtW3eg+jNNfVUuNE3iYkpMcm7HUyELrpOAqnCnlNZR+q7xb+TPexfvCZLnFP9jtbGFoEY6kZu1ESEn/LtfUBB6VsOsd/rkCLYwD8hqBi891lSO0OXUbyuoQi0fBoLJptygMz7QwnYFE0ojQ2MpwNSwqqkRor9++qkMYvxOPGXjYKpFcASBsBSBQFUJbvQbkOgjZAsJWPeYCwhojKIsUUM+drkHGZxgh0yBCffoZ4Y8CYeUhkz8lhCFBMBhc/Q/xBYJQY2JsgwhZtayOpKdJepP0UWgc1NsgQq6+L6CP0Og1GnvSUp9rdozPLoRCrv5+nBborZym1yhCkrLFXLwZy7Zx6jlbcgJfEwixnaEVhMQj62P4oD+t4E3fGCX1g/MTEgKVJzA3yEMbGdTB4ukE6i6KOuCieYSUZvK2UYTCw7F+jystUon5iYdj85NwQ0lXJ0P4cJMIyb4Q65TtqfEdLJeUCQebl1JS36HfaK6DUOgfPSStp8fSa/MeXIpGwevqn+9X0iIvzVeei9foOrSZnd2puD8oSaIoBRP+eErWSqY1jpBnRP3GOh2ErvToKJVcCLkmgWNeHLhp8AqhUE+aZ6TMZOUxqg0iZM2pZFDkFYlUhIo8E8yk5OqepUYRKpRF+c/XxYEImiWkeggpRsxM47HnBJ9RPVBH6BctwdeMgdIBrI1LqewL8ml/xjeeAtqJZ4IKnxh3miuHsNRHyKgHWPDpfwuz5y14/BHW3fKcIjE8Xx+h0QjhgmtMkvxfVZ+g2dN/NfNtz8SEa+9wkUYRst0+ScnspFgZ96JB16DE8olUlapphIcM1iAr/w54V+gBPLAD86Fcv2veUb4utRF6hYn+hb70w/nTGmekGF0eV5/CSf2Twr4R7o6ld5xoJQjXsLhOTr2WztgrjUYDPOQ5xPgN/OlVzLCTulvxa1fg9RhVNtZLG6HQL3GSH9AJXo3jpoyBUN/oABWcL9r/RhHaT4xmZPUEUzOpB8Hj3lLB8z62rXwtNoAQK/q5/3gDhtAjnKjHgaBa/gNx7io9WvYr2gg9SmyUX/sKZ/prjf/3CorDwUvx4pMNIWSdrLw89C8zi7YQD3JxYmmBU77x5bBddrL7XYcIMjsLAc/KMNkIAoZmV7yIt+MQUw+hcYJ3WPjEVy5wXzQPnwilwZvwvyY0hpAMi5blcZ/PFx/+na+SfvfozR2fD0te8RS+xnkIevAbuMDAEv69UZ7ixW+AIbOLuEehixBVZo/C81LmK2MNHhq8E+mgPz4teItTnHUQmvHS43GfXwLiOET6L4AAAAruSURBVFGqJI6TRCmTSrU5zY3zELek/+OCNeT5DnNpMViIY66A17gCeDrgl4pnQFQjDHjxlLy1ROYrjwb7VCk1CpMLp799KOyd5aCHELRIKpjuS+fHApUnAElzBej3sb6+XXbveKX6CMEqg1AGVv77CP9ejGdArcIH/m6Bo7V5iKPUhf6xhYWeGhPHjeB3GwVD6GF6NhAoHDungxBbCOxBZizNkWai8vnqas8JPJ5OK3FSLtIwQuprYMer91YWVYTUf/CUP8/beG+gZBxeFULAFxB60hOB2pP/AaIX7MkY1fcYdJfgrbsObWbg4Vga/55SEQqo93mGSytBsPwFJjYipahXnvvMu9KJCd8BHu8GLhY4WvK6ak0T6BlTuL4FnZnxuPgmRAcn+ueNXnWMuq4uNbPjEiJk8n5Vaa4P7+HIgXTab4ePomGEPKqZwNJFYYm8bJT5Gq5qcgk5atVH6PW60occlJSZ1g521XNvQZse6hgFgzHtrbsOsS47LgLCmsMJ4XFlLJ1OtRV9N12ECg5gYHpdRqPnntfwrso0YKHR+5kHTIfJRMdKupY01uFDLgavAPbUjPpBF3kUy6iFEjPA6kC9dYidkfyYDkKAqIwp6YxscxYONtVDyCjAc8sKXMeSJ2D8jrCQ+gbUzMWLgYtdiHCU4YvBfzXCUJ9y6BDHf/ua1uGZRXIp4CQpom8B46q6CFNSWo+HaNzGxLGgvTgLqQ5CC8+BmjF4loiFx1U4uGIUPJ95hNfxj5PRosXGhiqEQj9mBvjkay4dgAahD95D9Psm8ycg6K5D1sf0K6qmqY2QG1PiciFnoy+loJOzK6DugIVetPAxBYy90XhxKRB4F5fhAA4YqYnQa/SkHTyfuL6gm3wL9PStrWWAhXmjr4uwOyk+5KoQll/6GJdOJ+zFg9z0EHLEfTF6PUuga1bg784rgy7QDvc8hsAqzhF3KNzeuV3VCA3Gh/71jO+uoCulBq9n4bT/MR58h+ZRD6GtzS6lH1IaPCy5eFiHSr+009A6hF88iqZhCSI74XUT/WhC+gau4+ISGHI0hwOk34irxUM8TOu5bxemhTq7UULP44fKhFe19/rr0OmT+vsAYXHDC3Qhnoc5wOzlAhWIxx4qSbmOtUCXCEhawmPMl1CWvqOt/3h8FffOljwQ2MGqHE7rxxY4BSOU7n887dLLEXtDfSKjrM0LRhL/63ttckacSDPpMaXQtkUxwZijYzQWzI9+xT6ofpHr6wsWKphrIMSD1rBY+Ve4Ni6uwAUCpEdf9KMiRcBGNIev1UGIqvGhwnPZeY+OzRf6xVEHI8UXBLSOdRCGE0qPwigP03mEyMNRYOL54rnLitLXzzHpCXHXrotQnUVguQq2T/Degw86AB7NX/77qsfgQlMBXuoQvTirlC1xDXsoTIij4Lqu363Nw0CP4mgHcU/EPejG1pHSlDQ2IVKW9MO0kidOUdLZLKAGlcDhvb6HisIDp5NOfR7iWBsMA+HSEJFB+I6OXfpsBXUBGH+vEYzFX/5d7hhWIgSfUxizoMmXfBM1mQg+Gz/q4BVpdyLgradpnD4ROASsS/fXJhG0A6jbYLfuOsQCMw4BGgPozkD0O0SPXvrCg/J5EY9QWqW7fj2p6EupAbw23gImVdx9XFvZAE/AbeCDuxP1oyd7hlfSOBCLV0SlBmGnHgQYfDBVi4f5FSsqYyt4VJJhadJrDLjepmOOSx40Wfcw1pt9RH/5y1f1eQhCakxbcEMguDOh6ZmiM4efAsbY8YxLqBs9yX6e28tLlzrd5YYAz4mVdmogVHhSc3ro6MoU/MWA9+JFYyDgehGse5ZI6yQqVmGp01ofIUjpY4zXpHimx2sshH8F/qKqxU9MeJwIisG4b0Flsx5CNhzkKaahwn2eknzOGjwkHeyWGD30aPXVldmV/85Oza683QnB7r9Rr3qXSFIQVmX2l98o+vlS1MD9a2t+X3w6NJFPinr30oaCNxDCXGloIRP3ZQohli5Cu0SmsTUAkKfEeA2EjMJbeCWm1oF1dg0vLi4OYZHS0DdgGQ2BSTCQBvRvBrK//lrk9HUp2EPXwldfBScm0iKX9S+gb1PMR4H984BdU/wLs+nHk0XPVX8d4kGoDSGk8LDmGggxjCyftwe0uDobwHM+weeGS1t5RLc7sr/8Wizbq9GQUrxeIQSq3QIObHAVXU8EGFA1bQ+ECAojrX47FspnAepFT8hDXn9/iBCeIVoTIbYJj1rzs6GKRwgNXfjtyiyI2dJKIGBcAY+tg+J++X/LxyFoIST1MR6Fj8UsDJ/MgMkDyC6XCx25UJ9lIOYALRp/XHJCah0p5fjqORpaPASMtRCCKsbhwSartXCuUR5k5+Kbv/nuu9XV1bcxXxPjuRcule8oauVLUVkKj2FZxywKJe2A3yJM9KXTfQs9XsEjWgbQd+fBNS/Rr3o8DCfwpNcGCIWrppQyh3Dwjgov34avcdoSuLpiRT9Prb0nVz9PoVVkpPH+APhooMqkq3cnwN/hLaRpCwzFXhJAF2F3km/k6AFUJhwTr4WwahF2aZTFWiH05SoOS6yB0Cj0WzgyqjGY6g/185wDJEhaTfYAQhx2yIs7d12GxnZm2F2xgYICspfEF8ZaVUupJdbZ1YlFsIuLjx49+nhm5lEVAzE/QwS0rpQS9QFQeAymM77HsCQHOkbRhdnpDyk4nRPHA90N7SXE6/ilwYY0DeqjpL2G18bw2aO9QEePDg5mGXDVR/eKdosA6S8ZS9WfqrlDGuqTJLBPyZQ/1E9RMXoAeI8+zFhWgjdJjGc8JVWYdfKlcamx9hIQGKeOX0rSyTyODFUUR/WUT7rzO/joq5JBtaTUEPDcXU8mfTt3x9JpXnGMWnAyWSaupPvh4fh4Bu2ktyEegjaNBzn1ZHtejWD3ij/JJE+S6odviZ3CBKQaCAvOHlcyELqwGBc/nrFoSUrtXW6w+/OZuws9oZ40zufHuR1UPP7YJcDDGdA5XmOp9tXdmTGz7rifUDKZzGQy8SLBnSSeU5FIJPzJXbuzMMWqTp6GKhnUerALFubH3509ahFx03QfCEHbhEJg1Q2Bfsw+4ictpTJg9MnD+6g2IZVPTnmPSE+rjFNNncXH7biF6DTb9Hi4J80cN/Mxoe9mzs7MHB3MKiLWDnGUhtJuoOorMCFZSDW5lAH1grFE9ca3bnxoNudz2SqDCkfQYlGULb8hrD5jM7ON8JDHk1OIkIsibv3y6grgOM3KmvoIwb/pX0PnGQBmJrzV+/p1eWjO72gjGFblklmlwg/4JGG1rZF9izJjgFk1AgTPf1P2J6V5AueMKJ3MeCrzMKR9PGwdTWNWp8SpQGx7EwFs5LAf9b+58NL6CBWl0EXNE2+WImN8qBoWqQEp9XoF18LdTF69aDLxR159SRgZcrkq1ctPC2Gdp38SCOvA/xnhTxFhS6f6lSBs6XBNIL6AsOp4c/XKDQ08jFSN0NnG1jm2T4fwkKoCQnRFW4Cpnq5pdXlbYSKmGCsRunH73tYs4eiSfJc5JoxbQVjsXTMKxmYJU3GByYrT40fCTnvzPGwzq13mJjzltiU5JafuwrWdeEVno6kuC8Ebn0rS5Qixh9TeShfpiHrgkbXlk5PVMMR6YtLT0zy5Jk+Ud6vjrLiWuoAPHqSt+eOmre3YBtx0rzlNq+9EN9kDXOgEpukKhHSrZCrNq7X6PqYneIz8E+tWf2bpZ4Q/fvoZ4Y+ffvoI/x8QDd0Q0LqMqgAAAABJRU5ErkJggg==", "#5B0147", "pink one ...", 1));
//


//product set
//        products = new ArrayList<>();
//        products.add(new Product("Ready To Ware", "https://i.pinimg.com/564x/00/44/0e/00440ed34a286da0e3266e9a1066d77b.jpg", "", "S,M,L,X", 10000, 20, 40, 1, 13));
//        products.add(new Product("Pink Abaya's", "https://i.pinimg.com/236x/38/27/10/382710db01ff31c5effccdd77198ecb0.jpg", "", "S,M,L,X", 2000, 20, 40, 1, 13));
//        products.add(new Product("Latest dress", "https://i.pinimg.com/236x/23/86/2a/23862a34a1ad3dfbca0cc60bde242bf8.jpg", "", "S,M,L,X", 15000, 20, 40, 1, 13));
//        products.add(new Product("Beautifull dress", "https://i.pinimg.com/236x/02/c0/24/02c024b0b971431ccd16f3c0025cda09.jpg", "", "S,M,L,X", 17000, 20, 40, 1, 13));
//        products.add(new Product("Pink Abaya's", "https://cdn0.iconfinder.com/data/icons/muslim-arabic-woman-in-hijab-and-abaya-2/5/Muslim_woman_color-21-128.png", "", "S,M,L,X", 100, 20, 40, 1, 13));
//        products.add(new Product("ready to ware by GullRang", "https://i.pinimg.com/564x/00/4b/c9/004bc966babc5030002d5158820c67e5.jpg", "", "S,M,L,X", 100, 20, 40, 1, 13));
//        products.add(new Product("Dress", "https://i.pinimg.com/236x/1a/77/8d/1a778dc268350fcc5f5844e3c87f96e9.jpg", "", "S,M,L,X", 100, 20, 40, 1, 13));
//        products.add(new Product("Beautifull dress", "https://i.pinimg.com/236x/02/c0/24/02c024b0b971431ccd16f3c0025cda09.jpg", "", "S,M,L,X", 17000, 20, 40, 1, 13));
//        productAdapter = new ProductAdapter(this, products);
