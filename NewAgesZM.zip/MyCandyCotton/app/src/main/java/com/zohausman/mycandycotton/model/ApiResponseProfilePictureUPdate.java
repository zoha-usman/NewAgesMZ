package com.zohausman.mycandycotton.model;

public class ApiResponseProfilePictureUPdate {
    public String msg;
    public String sts;
    public String pic_name;
    public String img_path;
    public String action;
    public boolean status;

    public ApiResponseProfilePictureUPdate() {
    }

    public ApiResponseProfilePictureUPdate(String msg, String sts, String pic_name, String img_path, String action, boolean status) {
        this.msg = msg;
        this.sts = sts;
        this.pic_name = pic_name;
        this.img_path = img_path;
        this.action = action;
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getSts() {
        return sts;
    }

    public void setSts(String sts) {
        this.sts = sts;
    }

    public String getPic_name() {
        return pic_name;
    }

    public void setPic_name(String pic_name) {
        this.pic_name = pic_name;
    }

    public String getImg_path() {
        return img_path;
    }

    public void setImg_path(String img_path) {
        this.img_path = img_path;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
