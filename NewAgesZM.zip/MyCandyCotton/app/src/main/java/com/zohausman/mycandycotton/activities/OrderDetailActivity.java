package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.model.OrderDataResponseModel;

import com.zohausman.mycandycotton.adapter.OrderDetailAdapter;
import com.zohausman.mycandycotton.apicontroller;

import com.zohausman.mycandycotton.model.orderResponse;

import java.util.ArrayList;
import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderDetailActivity extends AppCompatActivity {
    //      OrderDetailActivity binding;
    private RecyclerView recyclerView;
    private OrderDetailAdapter orderAdapter;
    private List<OrderDataResponseModel> orders;
    private MeowBottomNavigation OBottomNavigation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        binding = OrderDetailActivity.inflate();
        setContentView(R.layout.activity_order_detail);


        try{
           OBottomNavigation= findViewById(R.id.OBottomNavigation);

            OBottomNavigation.add(new MeowBottomNavigation.Model(1, R.drawable.ic_home));
            OBottomNavigation.add(new MeowBottomNavigation.Model(2, R.drawable.ic_category));
            OBottomNavigation.add(new MeowBottomNavigation.Model(3, R.drawable.ic_cart_white));
            OBottomNavigation.add(new MeowBottomNavigation.Model(4, R.drawable.ic_profile));

            OBottomNavigation.show(1, true);

            OBottomNavigation.setOnClickMenuListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {

                        case 1:

                            Intent homeintent= new Intent(OrderDetailActivity.this, DashBoard.class);
                            startActivity(homeintent);
                            break;
                        case 2:
                            Intent catintent = new Intent(OrderDetailActivity.this,CategoryActivity.class);
                            startActivity(catintent);
                            break;
                        case 3:
                            Intent cartintent= new Intent(OrderDetailActivity.this, CartActivity.class);
                            startActivity(cartintent);
                            break;
                        case 4:
                            Intent profileintent= new Intent(OrderDetailActivity.this, UerProfileActivity.class);
                            startActivity(profileintent);
                            break;

                    }
                    return null;
                }
            });

            OBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 1:
                            Intent homeintent= new Intent(OrderDetailActivity.this, DashBoard.class);
                            startActivity(homeintent);
                            break;
                    }
                    return null;
                }
            });

            OBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 2:
                            Intent catintent = new Intent(OrderDetailActivity.this,CategoryActivity.class);
                            startActivity(catintent);
                            break;
                    }
                    return null;
                }
            });
            OBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 3:
                            Intent cartintent= new Intent(OrderDetailActivity.this, CartActivity.class);
                            startActivity(cartintent);
                            break;
                    }
                    return null;
                }
            });
            OBottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
                @Override
                public Unit invoke(MeowBottomNavigation.Model model) {
                    // YOUR CODES
                    switch (model.getId()) {
                        case 4:
                            Intent profileintent= new Intent(OrderDetailActivity.this, UerProfileActivity.class);
                            startActivity(profileintent);
                            break;
                    }
                    return null;
                }
            });


        }catch(Exception e){
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        Context context = this;

        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        String UserId = sp.getString("userid", "");


        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        orders = new ArrayList<OrderDataResponseModel>();
        orderAdapter = new OrderDetailAdapter(this,orders);
        recyclerView.setAdapter(orderAdapter);


        // Make API call to fetch order details
        getOrderDetails();

    }

    private void getOrderDetails() {

     Context context = this;

        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        String userId = sp.getString("userid", "");

        Toast.makeText(context, "user_id:"+userId, Toast.LENGTH_SHORT).show();

        Call<orderResponse> call = apicontroller.getInstance().getapiSet().showOrderDetails("show_order_details",userId);

        call.enqueue(new Callback<orderResponse>() {
            @Override
            public void onResponse(Call<orderResponse> call, Response<orderResponse> response) {
                if (response.isSuccessful()) {
                    orderResponse orderResponse = response.body();

                    if (orderResponse != null && orderResponse.isSts()) {
                        List<OrderDataResponseModel> orderDetails = orderResponse.getData();
                        orders.addAll(orderDetails);  // Add orderDetails to orders list
                        orderAdapter.notifyDataSetChanged();
                    }
                }
            }

            @Override
            public void onFailure(Call<orderResponse> call, Throwable t) {
                // Handle failure
                Toast.makeText(OrderDetailActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}