package com.zohausman.mycandycotton;

import com.google.gson.GsonBuilder;
import com.zohausman.mycandycotton.InterfaceApi_z.apiset;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class apicontroller {

//    http://localhost/ecommapi/index.php
//    static final String url="http://192.168.1.8/ecommapi/api";
//    home api
//    static final String url="http://192.168.100.26/ecommapi/api/";
//    static final String url="https://newagesfyp.000webhostapp.com/api/";
    static final String url="https://newageszm.000webhostapp.com/api/";
//    static final String url="http://192.168.43.223/ecommapi/api/";
//    office
//    static final String url="http://192.168.1.34/ecommapi/api/";

//    static final String url="http://192.168.1.17/ecommapi/api/";
//    static final String url="http://192.168.1.45/ecommapi/api/";
//    static final String url="http://192.168.1.20/ecommapi/api/";
//    static final String url="http://192.168.0.116/ecommapi/api/";
//    static final String url="http://192.168.1.104/ecommapi/api/";
//    static final String url="http://10.1.43.16/ecommapi/api/";

//    object of this class apicontroller
    private static apicontroller clientobject;
//    object of retrofit
    private static Retrofit retrofit;
// constructor
    apicontroller()
    {
        GsonBuilder gsonBuilder= new GsonBuilder();
        gsonBuilder.setLenient();
        retrofit=new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create(gsonBuilder.create()))
                .build();
    }

 //runtime object
    public static synchronized apicontroller getInstance()
    {
        if(clientobject==null)
            clientobject=new apicontroller();
        return clientobject;
    }

//    api (which api we are going to used)
    public apiset getapiSet()
    {
        return retrofit.create(apiset.class);
    }
}
