package com.zohausman.mycandycotton.model;

public class index_response_model {
    private String msg;
    private boolean status;
    private String action;

    public index_response_model() {
    }

    public index_response_model(String msg, boolean status, String action) {
        this.msg = msg;
        this.status = status;
        this.action = action;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
