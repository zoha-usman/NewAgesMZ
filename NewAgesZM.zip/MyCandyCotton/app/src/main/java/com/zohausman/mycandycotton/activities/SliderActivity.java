package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;
import com.zohausman.mycandycotton.R;

import android.content.Intent;
import android.os.Bundle;
import android.transition.Slide;
import android.view.View;

import com.zohausman.mycandycotton.databinding.ActivitySliderBinding;

import org.imaginativeworld.whynotimagecarousel.model.CarouselItem;

public class SliderActivity extends AppCompatActivity {
  ActivitySliderBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySliderBinding.inflate(getLayoutInflater());
//        binding = ActivitySliderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        setContentView(R.layout.activity_slider);

        initSlider();
        binding.getStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SliderActivity.this, DashBoard.class);
                startActivity(intent);
            }
        });



    }


    private void initSlider() {
        int image1 = R.drawable.girlsslider;
        int image2 = R.drawable.kisdsslider;


        binding.carouselSlider.addData(new CarouselItem(image1, "Slider 1"));
        binding.carouselSlider.addData(new CarouselItem(image2, "Slider 1"));

    }

}