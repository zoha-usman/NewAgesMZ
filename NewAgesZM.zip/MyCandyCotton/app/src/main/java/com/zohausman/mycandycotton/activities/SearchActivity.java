package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import android.os.Bundle;
import android.widget.Toast;

import com.zohausman.mycandycotton.adapter.ProductAdapter;
import com.zohausman.mycandycotton.apicontroller;
import com.zohausman.mycandycotton.databinding.ActivitySearchBinding;
import com.zohausman.mycandycotton.model.Showall;
import com.zohausman.mycandycotton.model.productDispData;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Query;

public class SearchActivity extends AppCompatActivity {
 ActivitySearchBinding binding;
     ProductAdapter productAdapter;
    private ArrayList<productDispData> products;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        setContentView(R.layout.activity_search);
        products = new ArrayList<>();
        productAdapter = new ProductAdapter(this, products);


        String query = getIntent().getStringExtra("query");


        getProducts(query);
//        initProducts(query);
        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        binding.productList.setLayoutManager(layoutManager);
        binding.productList.setAdapter(productAdapter);
    }
            private void getProducts (String query){
            Call<Showall> call = apicontroller.getInstance().getapiSet().getProductsByCategory(query);
            call.enqueue(new Callback<Showall>() {
                @Override
                public void onResponse(Call<Showall> call, Response<Showall> response) {
                    if (response.isSuccessful()) {
                        Showall showall = response.body();
                        if (showall != null && showall.getData() != null) {
                            List<productDispData> productList = showall.getData();
                            products.addAll(productList);
                            productAdapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(SearchActivity.this, "No products found", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(SearchActivity.this, "Failed to fetch products", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Showall> call, Throwable t) {
                    Toast.makeText(SearchActivity.this, "Failed to fetch products: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

//    private void initProducts(String query) {
//
//        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
//        binding.productList.setLayoutManager(layoutManager);
//        binding.productList.setAdapter(productAdapter);
//
//        AllProductShow();
//    }

//    private void AllProductShow() {
//        Call<Showall> call = apicontroller.getInstance()
//                .getapiSet().getProducts();
//        call.enqueue(new Callback<Showall>() {
//            @Override
//            public void onResponse(Call<Showall> call, Response<Showall> response) {
//                if (response.isSuccessful()) {
//                    Showall showall = response.body();
//                    List<productDispData> productList = showall.getData();
//                    // productList to adapter and display the data in the RecyclerView
//                    ProductAdapter adapter = new ProductAdapter(SearchActivity.this, productList);
//                    binding.productList.setAdapter(adapter);
//
//
//
//                } else {
//                    // Handle the error case
//                }
//            }
//
//            @Override
//            public void onFailure(Call<Showall> call, Throwable t) {
//                // Handle the network failure case
//                Toast.makeText(SearchActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }



    @Override
    public boolean onSupportNavigateUp () {
        finish();
        return super.onSupportNavigateUp();
    }
}