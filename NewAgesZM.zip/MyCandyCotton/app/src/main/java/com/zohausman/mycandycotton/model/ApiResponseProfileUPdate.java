package com.zohausman.mycandycotton.model;

public class ApiResponseProfileUPdate {
    public String msg;
    public boolean status;
    public String action;

    public ApiResponseProfileUPdate() {
    }

    public ApiResponseProfileUPdate(String msg, boolean status, String action) {
        this.msg = msg;
        this.status = status;
        this.action = action;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
