package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.hishd.tinycart.model.Cart;
import com.hishd.tinycart.model.Item;
import com.hishd.tinycart.util.TinyCartHelper;
import com.zohausman.mycandycotton.adapter.CartAdapter;
import com.zohausman.mycandycotton.apicontroller;
import com.zohausman.mycandycotton.databinding.ActivityCheckoutBinding;
import com.zohausman.mycandycotton.model.Product;
import com.zohausman.mycandycotton.model.orderApiResponse;
import com.zohausman.mycandycotton.model.productDispData;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckoutActivity extends AppCompatActivity {
    ActivityCheckoutBinding binding;
    CartAdapter adapter;
    ArrayList<productDispData> products;
    double totalPrice = 0;
    final int tax = 11;
    ProgressDialog progressDialog;
    Cart cart;
    String userID;

    private ArrayList<Integer> productIds;
    private ArrayList<String> sizes;
    private ArrayList<Integer> quantities;
    private ArrayList<Double> prices;
    private ArrayList<Double> subTotals;

    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCheckoutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//        setContentView(R.layout.activity_checkout);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Processing...");


        products = new ArrayList<>();

        cart = TinyCartHelper.getCart();

        // Initialize the product lists
        productIds = new ArrayList<>();
        sizes = new ArrayList<>();
        quantities = new ArrayList<>();
        prices = new ArrayList<>();
        subTotals = new ArrayList<>();

        for(Map.Entry<Item, Integer> item : cart.getAllItemsWithQty().entrySet()) {
            productDispData product = (productDispData) item.getKey();
            int quantity = item.getValue();
            product.setQuantity(String.valueOf(quantity));

            products.add(product);
            // Add the product details to the lists
            productIds.add(product.getId());
            sizes.add(product.getSize());
            quantities.add(quantity);
            prices.add(product.getPrice());
            subTotals.add(product.getPrice() * quantity);
        }

        adapter = new CartAdapter(this, products, new CartAdapter.CartListener() {
            @Override
            public void onQuantityChanged() {
                binding.subtotal.setText(String.format("PKR %.2f",cart.getTotalPrice()));
            }
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
//        DividerItemDecoration itemDecoration = new DividerItemDecoration(this, layoutManager.getOrientation());
        binding.cartList.setLayoutManager(layoutManager);
//        binding.cartList.addItemDecoration(itemDecoration);
        binding.cartList.setAdapter(adapter);

        binding.subtotal.setText(String.format("PKR %.2f",cart.getTotalPrice()));

        totalPrice = (cart.getTotalPrice().doubleValue() * tax / 100) + cart.getTotalPrice().doubleValue();
        binding.total.setText("PKR " + totalPrice);

        binding.checkoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processOrder();
                Intent intent = new Intent(CheckoutActivity.this, OrderSuccessActivity.class);
                startActivity(intent);



            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



    }

    private void processOrder() {
        // get the user details from user input

        String userName = binding.nameBox.getText().toString();
        String userEmail = binding.emailBox.getText().toString().trim();
        String userPhone = binding.phoneBox.getText().toString();
        String userAddress = binding.addressBox.getText().toString();
////        String userCity = binding.cityBox.getText().toString();
        // Convert ArrayList<Integer> to int[]
        int[] productIdsArray = productIds.stream().mapToInt(Integer::intValue).toArray();

// Convert ArrayList<String> to String[]
        String[] sizesArray = sizes.toArray(new String[0]);

// Convert ArrayList<Integer> to int[]
        int[] quantitiesArray = quantities.stream().mapToInt(Integer::intValue).toArray();

// Convert ArrayList<Double> to double[]
        double[] pricesArray = prices.stream().mapToDouble(Double::doubleValue).toArray();

// Convert ArrayList<Double> to double[]
        double[] subTotalsArray = subTotals.stream().mapToDouble(Double::doubleValue).toArray();

//
        // Get the user ID from SharedPreferences
        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        String userId =sp.getString( "userid", "");
//        Toast.makeText(this, "user_id"+userId, Toast.LENGTH_SHORT).show();

        // Prepare the lists for product details
        List<Integer> productIds = new ArrayList<>();

        List<String> sizes = new ArrayList<>();
        for (productDispData product : products) {
            String size = product.getSize();
            sizes.add(size);
        }

        List<Integer> quantities = new ArrayList<>();
        for (productDispData product : products) {
            int quantity = Integer.parseInt(product.getQuantity());
            quantities.add(quantity);
        }
        List<Double> prices = new ArrayList<>();
        for (productDispData product : products) {
            double price = product.getPrice();
            prices.add(price);
        }
        List<Double> subTotals = new ArrayList<>();
        for (productDispData product : products) {
            double price = product.getPrice();
            int quantity = Integer.parseInt(product.getQuantity());
            double subTotal = price * quantity;
            subTotals.add(subTotal);
        }


        try{


        // Call the placeOrder API
        Call<orderApiResponse> call = apicontroller.getInstance().getapiSet().placeOrder(  "place_order",
                userId,
                userName,
                userEmail,
                userPhone,
                userAddress,
                userId,
                1,
                productIdsArray,
                sizesArray,
                quantitiesArray,
                pricesArray,
                subTotalsArray);
        call.enqueue(new Callback<orderApiResponse>() {
            @Override
            public void onResponse(Call<orderApiResponse> call, Response<orderApiResponse> response) {
                if (response.isSuccessful()) {
                    // Process the response here
                    orderApiResponse orderResponse = response.body();
                    if (orderResponse != null && orderResponse.isSts()){
                        String message = orderResponse.getMsg();
                        // Handle successful order placement
                        Toast.makeText(CheckoutActivity.this, message, Toast.LENGTH_SHORT).show();
                    } else {
                        // Handle unsuccessful order placement
                        Toast.makeText(CheckoutActivity.this, orderResponse.getMsg(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Handle API call failure
                    Toast.makeText(CheckoutActivity.this, "failed to upload data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<orderApiResponse> call, Throwable t) {
                // Handle network failure or API call exception

            }
        });

        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        // Show the progress dialog
//        progressDialog.show();


    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}
