package com.zohausman.mycandycotton.model;

import android.net.Uri;

public class Review {
    private String reviewText;
    private Uri imageUri;

    public Review(String reviewText, Uri imageUri) {
        this.reviewText = reviewText;
        this.imageUri = imageUri;
    }

    public String getReviewText() {
        return reviewText;
    }

    public Uri getImageUri() {
        return imageUri;
    }

    public void setReviewText(String reviewText) {
        this.reviewText = reviewText;
    }

    public void setImageUri(Uri imageUri) {
        this.imageUri = imageUri;
    }
}

