package com.zohausman.mycandycotton.model;

public class orderApiResponse {
    public String msg;
    public boolean sts;
    public String action;

    public orderApiResponse() {
    }

    public orderApiResponse(String msg, boolean sts, String action) {
        this.msg = msg;
        this.sts = sts;
        this.action = action;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isSts() {
        return sts;
    }

    public void setSts(boolean sts) {
        this.sts = sts;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
