package com.zohausman.mycandycotton.activities;


import androidx.appcompat.app.AppCompatActivity;


import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.apicontroller;
import com.zohausman.mycandycotton.databinding.ActivityUerProfileBinding;
import com.zohausman.mycandycotton.model.ApiResponseProfileUPdate;
import android.content.Intent;
import android.content.SharedPreferences;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class UerProfileActivity extends AppCompatActivity {
    ActivityUerProfileBinding binding;
    String UserID;


    private MeowBottomNavigation profileBottonNav;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUerProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        String userId = sp.getString("userid", UserID);
        String fullName = sp.getString("username", "");
        String email = sp.getString("useremail", "");
        String password = sp.getString("password", "");
        String contact = sp.getString("contact", "");
        String address = sp.getString("address", "");
        String city = sp.getString("city", "");
//        Toast.makeText(this, "userId:" + userId, Toast.LENGTH_SHORT).show();


        // Bind data to corresponding views
        binding.fullNameProfile.setText(fullName);
        binding.EmailProfile.setText(email);
        binding.PasswordProfile.setText(password);
        binding.contactNunber.setText(contact);
        binding.Address.setText(address);
        binding.City.setText(city);



        // Set click listener for the update button
        binding.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleUpdateProfile();
            }
        });

        profileBottonNav = findViewById(R.id.pBottomNavigation);
        profileBottonNav.add(new MeowBottomNavigation.Model(1, R.drawable.ic_home));
        profileBottonNav.add(new MeowBottomNavigation.Model(2, R.drawable.ic_category));
        profileBottonNav.add(new MeowBottomNavigation.Model(3, R.drawable.ic_cart_white));

        profileBottonNav.setOnClickMenuListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                // Handle bottom navigation item click here
                int id = model.getId();
                switch (id) {
                    case 1:
                        // Handle home click
                         startActivity(new Intent(UerProfileActivity.this, DashBoard.class));
                        break;
                    case 2:
                        // Handle favorite click
                         startActivity(new Intent(UerProfileActivity.this, CategoryActivity.class));
                        break;
                    case 3:
                        // Handle profile click
                        // No need to take any action as we are already on the profile page
                        startActivity(new Intent(UerProfileActivity.this, OrderDetailActivity.class));

                        break;
                }
                return null;
            }
        });



    }

    private void clickListeners() {


    }


    //++++++++++++++++++++++++++++++++for Update the other data of user
    private void handleUpdateProfile() {
        // Get the updated profile data from the views
        String userId = getUserIdFromSharedPreferences();
        String name = binding.fullNameProfile.getText().toString();
        String email = binding.EmailProfile.getText().toString();
        String password = binding.PasswordProfile.getText().toString();
        String address = binding.Address.getText().toString();
        String city = binding.City.getText().toString();
        String contact = binding.contactNunber.getText().toString();

        // Call the method to update the user profile
        updateUserProfile(userId, name, email, password, address, city, contact);
    }

    private String getUserIdFromSharedPreferences() {
        // Implement this method to retrieve the user ID from SharedPreferences
        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        return sp.getString("userid", "");
    }

    private String getPasswordFromSharedPreferences() {
        // method to retrieve the password from SharedPreferences
        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        return sp.getString("password", "");
    }

    private void updateUserProfile(String userId, String name, String email, String password, String address, String city, String contact) {
        // to update the user profile using the provided data
        // checkProfileUpdate method here
        checkProfileUpdate(userId, name, email, password, address, city, contact);
    }

    private void checkProfileUpdate(String userId, String name, String email, String password, String address, String city, String contact) {

        Call<ApiResponseProfileUPdate> call = apicontroller.getInstance().getapiSet().checkProfileUpdate(userId, name, email, password, address, city, contact);
        call.enqueue(new Callback<ApiResponseProfileUPdate>() {
            @Override
            public void onResponse(Call<ApiResponseProfileUPdate> call, Response<ApiResponseProfileUPdate> response) {
                if (response.isSuccessful()) {
                    ApiResponseProfileUPdate result = response.body();
                    // Handle the response accordingly
                    if (result != null && result.isStatus()) {
                        // Profile was updated
                        Toast.makeText(UerProfileActivity.this, "Profile was updated", Toast.LENGTH_SHORT).show();
                    } else {
                        // Profile was not updated
                        Toast.makeText(UerProfileActivity.this, "Profile was not updated", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Handle API error
                    Toast.makeText(UerProfileActivity.this, "API Error: " + response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponseProfileUPdate> call, Throwable t) {
                // Handle network or unexpected errors
                Toast.makeText(UerProfileActivity.this, "Failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


}