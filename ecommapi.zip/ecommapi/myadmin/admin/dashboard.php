<?php

include("header.php");
?>
<main>

<div class="section-1">
    <div class="container text-center">
        <h1 class="heading-1">Welcome to web Admin portal Dash board </h1>
</div>
</div>    
</main>

    <h4>
        Dashboard
</h4>
    
<?php
include("footer.php");
?>