<!DOCTYPE html>
<html lang="en">

<head>
  <?php include("inc/header.php");   ?>
</head>

<body>

  <?php include("inc/nav.php");   ?>
  <div class="container-fluid">
    <div class="row">
      <?php include("inc/sidebar.php");   ?>


      <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h2">Welcome To Dashboard</h1>
        </div>

        <div class="container">
          <?php
          $productsA =  countWhen($conn, "tbl_product", "status", "1");
          $orderA =  countWhen($conn, "tbl_orders", "order_status", "accepted");
          $delivered = countWhen($conn, "tbl_orders", "order_status", "delivered");
          $pending =   countWhen($conn, "tbl_orders", "order_status", "pending");
          ?>
          <div class="row">
            <a href="index.php" class="col-sm-3 thumbnail">
              <h4><span class="glyphicon glyphicon-home"></span> Home</h4>
            </a>
            <a href="products.php" class="col-sm-3 thumbnail">
              <h4><span class="glyphicon glyphicon-home"></span> Products </h4>
              <strong>Active: <?= $productsA ?></strong>
            </a>
            <a href="orders.php" class="col-sm-3 thumbnail">
              <h4><span class="glyphicon glyphicon-home"></span> Orders</h4>
              <strong>Active: <?= $orderA ?></strong> | <strong>Delivered: <?= $delivered ?></strong> | <strong>Pending: <?= $pending ?></strong>
            </a>
          </div>
        </div>



        <div class="row">
          <div class="col-md-6">
            <h4>Recent Orders</h4>
            <div class="table-responsive">
              <table class="table table-bordered table-striped table-sm">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Customer</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Address</th>
                    <th scope="col">Products</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>

                  <?php
                  $color_array = ['pending' => 'warning', 'accepted' => 'primary', 'delivered' => 'success', 'rejected' => 'danger'];
                  $result = mysqli_query($conn, "SELECT * FROM  tbl_orders ORDER BY order_id DESC LIMIT 5");
                  while ($row = mysqli_fetch_array($result)) {
                  ?>
                    <tr>
                      <td><?= $row['order_id'] ?></td>
                      <td><?= $row['useremail'] ?></td>
                      <td><?= $row['user_phone'] ?></td>
                      <td><?= $row['useremail'] ?></td>
                      <td><?= $row['user_address'] ?></td>
                      <td><!-- Button trigger modal -->
                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $row['order_id'] ?>">
                          Show Products
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal<?= $row['order_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Products</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                <table class="table table-bordered table-striped table-sm">
                                  <thead>
                                    <tr>
                                      <th scope="col">#</th>
                                      <th>Products</th>
                                      <th scope="col">Size</th>
                                      <th scope="col">Quantity</th>
                                      <th class="text-center">Price</th>
                                      <th class="text-center">Sub Total</th>
                                      <th class="text-center">Date</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <?php
                                    $product = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id = $row[order_id]");
                                    $i = 1;
                                    while ($show_product = mysqli_fetch_array($product)) {
                                    ?>
                                      <tr>
                                        <td><?= $i ?></td>
                                        <td><?= $show_product['product_id'] ?></td>
                                        <td><?= $show_product['size'] ?></td>
                                        <td><?= $show_product['qty'] ?></td>
                                        <td><?= $show_product['price'] ?></td>
                                        <td><?= $show_product['sub_total'] ?></td>
                                        <td><?= $show_product['date'] ?></td>
                                      </tr>
                                    <?php
                                      $i++;
                                    }
                                    ?>
                                  </tbody>
                                </table>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <button class="btn btn-sm  btn-<?= $color_array[$row['order_status']] ?>"><?= ucwords($row['order_status']) ?></button>

                      </td>
                    </tr>
                  <?php
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-6">
            <h4>Products List</h4>
            <div class="table-responsive">
              <table class="table table-bordered table-striped table-sm" style="text-transform: capitalize;">
                <thead>
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Category</th>
                    <th scope="col">Discription</th>
                    <th scope="col">Size</th>
                    <th scope="col">Quantity</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>

                  <?php
                  $color_array = ['1' => 'success', '0' => 'danger'];
                  $status_array = ['1' => 'active', '0' => 'inactive'];
                  $result = mysqli_query($conn, "SELECT * FROM  tbl_product LIMIT 5");
                  while ($row = mysqli_fetch_array($result)) {
                  ?>
                    <tr>
                      <td>
                        <a href="images/<?= $row['pimage'] ?>" data-fancybox data-caption="<?= $row['pimage'] ?>">
                          <img src="images/<?= $row['pimage'] ?>" alt="<?= $row['pimage'] ?>" style="width: 70px; height:70px">
                        </a>

                        <?= $row['pname'] ?>
                      </td>
                      <td><?= $row['catname'] ?></td>
                      <td><?= $row['price'] ?></td>
                      <td><?= $row['size'] ?></td>
                      <td><?= $row['stock'] ?></td>
                      <td>
                        <button class="btn btn-sm  btn-<?= $color_array[$row['status']] ?>"><?= $status_array[$row['status']] ?></button>
                      </td>

                    </tr>
                  <?php
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </main>
    </div>
  </div>

  <?php include("inc/foot.php");   ?>

</body>

</html>