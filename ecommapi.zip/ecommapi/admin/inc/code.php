<?php
include("functions.php");
if (isset($_REQUEST['add_category'])) {
    $cname = $_REQUEST['cname'];
    $sdesc = $_REQUEST['sdesc'];
    if ($_FILES['upload']) {
        $sn = $_FILES['upload']['tmp_name']; //mydocument/mypicture/hello.jpg
        $on = $_FILES['upload']['name']; //hello.jpg
        $dn = "catimages/" . $on;
        move_uploaded_file($sn, $dn);
        $qry = "INSERT INTO tbl_category (catname, image, sdesc, status) 
                                     VALUES ('$cname', '$on', '$sdesc', '1')";

        $res = mysqli_query($conn, $qry);
        if ($res == true) :
            $title = "Alert";
            $msg = "New Category Created";
            $sts = "success";
        else :
            $title = "Alert";
            $msg = mysqli_error($conn);
            $sts = "error";

        endif;
    }
}

if (isset($_REQUEST['add_products'])) {
    $catname = $_POST['category'];
    $pname = $_POST['pname'];
    $price = $_POST['price'];
    $sdesc = $_POST['sdesc'];
    $stock = $_POST['stock'];
    if ($_FILES['upload']) {
        $sn = $_FILES['upload']['tmp_name']; //mydocument/mypicture/hello.jpg
        $on = $_FILES['upload']['name']; //hello.jpg
        $dn = "../images/" . $on;
        move_uploaded_file($sn, $dn);
        $qry = "INSERT INTO tbl_product(catname ,pname,pimage, pdesc, price ,status, stock)
       VALUES ('$catname', '$pname', '$on', '$sdesc', '$price', '1', '$stock');";
        $res = mysqli_query($conn, $qry);
        if ($res == true) :
            $title = "Alert";
            $msg = "New Product Added";
            $sts = "success";
        else :
            $title = "Alert";
            $msg = mysqli_error($conn);
            $sts = "error";

        endif;
    }
}
if (!empty($_REQUEST['action'])) {
    if (!empty($_REQUEST['action']) and $_REQUEST['action'] == "accept_order" and !empty($_REQUEST['order_id'])) {
        $order_data = [
            "order_status" => "accepted"
        ];
        if (update_data($conn, "tbl_orders", $order_data, "order_id", $_REQUEST['order_id'])) {
            $title = "Alert";
            $msg = "Order Accepted";
            $sts = "success";
        }
    } elseif (!empty($_REQUEST['action']) and $_REQUEST['action'] == "reject_order" and !empty($_REQUEST['order_id'])) {
        $order_data = [
            "order_status" => "rejected"
        ];
        if (update_data($conn, "tbl_orders", $order_data, "order_id", $_REQUEST['order_id'])) {
            $title = "Alert";
            $msg = "Order Canceled";
            $sts = "error";
        }
    } elseif (!empty($_REQUEST['action']) and $_REQUEST['action'] == "delivered_order" and !empty($_REQUEST['order_id'])) {
        $order_data = [
            "order_status" => "delivered"
        ];
        if (update_data($conn, "tbl_orders", $order_data, "order_id", $_REQUEST['order_id'])) {
            $title = "Alert";
            $msg = "Order Delivered";
            $sts = "success";
        }
    }
}

if (isset($_REQUEST['delete_product'])) {
    $id = $_REQUEST['delete_product'];
    $query = "DELETE FROM tbl_product WHERE id='$id'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $title = "Alert";
        $msg = "Product Deleted";
        $sts = "success";
        redirect("products.php", 3000);
    }
}
if (isset($_REQUEST['delete_category'])) {
    $id = $_REQUEST['delete_category'];
    $query = "DELETE FROM tbl_category WHERE id='$id'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $title = "Alert";
        $msg = "Category Deleted";
        $sts = "success";
        redirect("category.php", 3000);
    }
}
