<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors" />
    <meta name="generator" content="Hugo 0.72.0" />
    <title>Dashboard Template · Bootstrap</title>
    <?php include("inc/header.php");   ?>
</head>

<body>
    <?php include("inc/nav.php");   ?>
    <div class="container-fluid">
        <div class="row">
            <?php include("inc/sidebar.php");   ?>


            <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Category</h1>
                </div>

                <div class="container">

                    <form method="post" enctype="multipart/form-data" class="row">
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1">Category Name</label>
                            <input type="text" name="cname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Category Name" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputPassword1">Category Thumbnail</label>
                            <input type="file" name="upload" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
                        </div>
                        <label for="exampleInputPassword1">Short Description</label>
                        <div class="form-group col-md-12">
                            <textarea name="sdesc" rows="5" cols="80" class="from-control" style="width: 100%;"></textarea>
                        </div>
                        <br />
                        <button type="submit" class="btn btn-primary" name="add_category">Submit</button>
                    </form>
                </div>

                <br>
                <h4>Category List</h4>
                <br>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sm" style="text-transform: capitalize;">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Price</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $color_array = ['1' => 'success', '0' => 'danger'];
                            $status_array = ['1' => 'active', '0' => 'inactive'];
                            $result = mysqli_query($conn, "SELECT * FROM  tbl_category");
                            while ($row = mysqli_fetch_array($result)) {
                            ?>
                                <tr>
                                    <td>
                                        <a href="catimages/<?= $row['image'] ?>" data-fancybox data-caption="<?= $row['image'] ?>">
                                            <img src="catimages/<?= $row['image'] ?>" alt="<?= $row['pimage'] ?>" style="width: 70px; height:70px">
                                        </a>
                                        &nbsp; <?= $row['catname'] ?>
                                    </td>
                                    <td><?= $row['sdesc'] ?></td>
                                    <td>
                                        <button class="btn btn-sm  btn-<?= $color_array[$row['status']] ?>"><?= $status_array[$row['status']] ?></button>
                                    </td>
                                    <th class="text-center">
                                        <div class="btn-group" role="group" aria-label="...">
                                            <a href="?delete_category=<?= $row['id'] ?>"> <button type="button" class="btn btn-sm btn-danger">Delete</button></a>
                                        </div>
                                    </th>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <?php include("inc/foot.php");   ?>

</body>

</html>