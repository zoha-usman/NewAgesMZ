<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors" />
    <meta name="generator" content="Hugo 0.72.0" />
    <title>Dashboard Template · Bootstrap</title>
    <?php include("inc/header.php");   ?>
</head>

<body>
    <?php include("inc/nav.php");   ?>
    <div class="container-fluid">
        <div class="row">
            <?php include("inc/sidebar.php");   ?>


            <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Order Details</h1>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sm">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Customer</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Email</th>
                                <th scope="col">Address</th>
                                <th scope="col">Products</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $color_array = ['pending' => 'warning', 'accepted' => 'primary', 'delivered' => 'success', 'rejected' => 'danger'];
                            $result = mysqli_query($conn, "SELECT * FROM  tbl_orders");
                            while ($row = mysqli_fetch_array($result)) {
                            ?>
                                <tr>
                                    <td><?= $row['order_id'] ?></td>
                                    <td><?= $row['useremail'] ?></td>
                                    <td><?= $row['user_phone'] ?></td>
                                    <td><?= $row['useremail'] ?></td>
                                    <td><?= $row['user_address'] ?></td>
                                    <td><!-- Button trigger modal -->
                                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $row['order_id'] ?>">
                                            Show Products
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal<?= $row['order_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Products</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <table class="table table-bordered table-striped table-sm">
                                                            <thead>
                                                                <tr>
                                                                    <th scope="col">#</th>
                                                                    <th>Products</th>
                                                                    <th scope="col">Size</th>
                                                                    <th scope="col">Quantity</th>
                                                                    <th class="text-center">Price</th>
                                                                    <th class="text-center">Sub Total</th>
                                                                    <th class="text-center">Date</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                $product = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id = $row[order_id]");
                                                                $i = 1;
                                                                while ($show_product = mysqli_fetch_array($product)) {
                                                                ?>
                                                                    <tr>
                                                                        <td><?= $i ?></td>
                                                                        <td><?= $show_product['product_id'] ?></td>
                                                                        <td><?= $show_product['size'] ?></td>
                                                                        <td><?= $show_product['qty'] ?></td>
                                                                        <td><?= $show_product['price'] ?></td>
                                                                        <td><?= $show_product['sub_total'] ?></td>
                                                                        <td><?= $show_product['date'] ?></td>
                                                                    </tr>
                                                                <?php
                                                                    $i++;
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm  btn-<?= $color_array[$row['order_status']] ?>"><?= ucwords($row['order_status']) ?></button>

                                    </td>
                                    <th class="text-center">
                                        <div class="btn-group btn-group-sm" role="group" aria-label="...">
                                            <?php
                                            if($row['order_status'] =="pending" or $row['order_status'] =="rejected" ):
                                            ?>
                                            <a href="?action=accept_order&order_id=<?= $row['order_id'] ?>"><button type="button" class="btn btn-sm btn-primary">Accept</button></a>
                                            <a href="?action=reject_order&order_id=<?= $row['order_id'] ?>"> <button type="button" class="btn btn-sm btn-danger">Reject</button></a>
                                           <?php else:?>
                                            <a href="?action=delivered_order&order_id=<?= $row['order_id'] ?>"> <button type="button" class="btn btn-sm btn-success">Delivered</button></a>
                                      <?php
                                            endif;
                                            ?>
                                        </div>

                                    </th>

                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <?php include("inc/foot.php");   ?>

</body>

</html>