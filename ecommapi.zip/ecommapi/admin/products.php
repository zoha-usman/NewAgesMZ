<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors" />
    <meta name="generator" content="Hugo 0.72.0" />
    <title>Dashboard Template · Bootstrap</title>
    <?php include("inc/header.php");   ?>
</head>

<body>
    <?php include("inc/nav.php");   ?>
    <div class="container-fluid">
        <div class="row">
            <?php include("inc/sidebar.php");   ?>


            <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Products</h1>
                </div>

                <div class="container">

                    <form name="frm" method="post" class="row" enctype="multipart/form-data">
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1">Select Category</label><br />
                            <select name="category" class="form-control">
                                <?php
                                $qry = "select * from tbl_category";
                                $raw = mysqli_query($conn, $qry);
                                while ($res = mysqli_fetch_array($raw)) {
                                ?>
                                    <option value="<?php echo $res['catname']; ?>"><?php echo $res['catname']; ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="exampleInputEmail1">Product Name</label>
                            <input required type="text" name="pname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Product Name">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="exampleInputPassword1">Product Thumbnail/Image</label>
                            <input required type="file" name="upload" class="form-control" id="exampleInputPassword1" placeholder="product image">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="exampleInputEmail1">Product Price </label>
                            <input required type="text" name="price" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Product Price">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="exampleInputEmail1">Product Stock </label>
                            <input type="text" name="stock" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Total Stock">
                        </div>
                        <div class="form-check col-md-12">
                            <label for="exampleInputPassword1">Short Description</label>
                            <textarea required name="sdesc" rows="5" cols="80" class="from-control" style="width: 100%;"></textarea>
                        </div>
                        <br />
                        <button type="submit" class="btn btn-primary" name="add_products">Submit</button>
                    </form>
                </div>

                <br>
                <h4>Products List</h4>
                <br>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sm" style="text-transform: capitalize;">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Category</th>
                                <th scope="col">Price</th>
                                <th scope="col">Size</th>
                                <th scope="col">Quantity</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $color_array = ['1' => 'success', '0' => 'danger'];
                            $status_array = ['1' => 'active', '0' => 'inactive'];
                            $result = mysqli_query($conn, "SELECT * FROM  tbl_product");
                            while ($row = mysqli_fetch_array($result)) {
                            ?>
                                <tr>
                                    <td>
                                        <a href="images/<?= $row['pimage'] ?>" data-fancybox data-caption="<?= $row['pimage'] ?>">
                                            <img src="images/<?= $row['pimage'] ?>" alt="<?= $row['pimage'] ?>" style="width: 70px; height:70px">
                                        </a>
                                        <?= $row['pname'] ?>
                                    </td>
                                    <td><?= $row['catname'] ?></td>
                                    <td><?= $row['price'] ?></td>
                                    <td><?= $row['size'] ?></td>
                                    <td><?= $row['stock'] ?></td>
                                    <td>
                                        <button class="btn btn-sm  btn-<?= $color_array[$row['status']] ?>"><?= $status_array[$row['status']] ?></button>
                                    </td>
                                    <th class="text-center">
                                        <div class="btn-group" role="group" aria-label="...">
                                            <a href="?delete_product=<?= $row['id'] ?>"> <button type="button" class="btn btn-sm btn-danger">Delete</button></a>
                                        </div>
                                    </th>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <?php include("inc/foot.php");   ?>

</body>

</html>